﻿using CCSBMS.App_code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CCSBMS
{
    public partial class LoginPage : System.Web.UI.Page
    {
        db sdb = new db();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            try
            {
                if (signinemail.Text == "")
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please Enter Email.');", true);
                }

                if (signinpassword.Text == "")
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please Enter Password');", true);
                }


                DataTable dt_userdata = new DataTable();
                string query = "select Id  from adminuser where email='" + signinemail.Text + "' and password='" + signinpassword.Text + "' ";

                dt_userdata = sdb.GetDataTable(query);

                if (dt_userdata.Rows.Count > 0)
                {
                    Session["ID"] = dt_userdata.Rows[0]["Id"].ToString();

                    Response.Redirect("~/Admin/WebForm1.aspx");
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Invalid user Credential.');", true);

                }

            }
            catch (Exception ex)
            {

            }

        }
    }
}