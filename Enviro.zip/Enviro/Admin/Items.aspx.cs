﻿using CCSBMS.App_code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CCSBMS.Admin
{
    public partial class Items : System.Web.UI.Page
    {
        db sqldb = new db();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["ID"] != null)
            {
                // AddItemDiv.Visible = false;
                GetItem();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please Login..., You are automatic redirect at User Login Window.'); window.location.href = '../Default.aspx';", true);
            }


        }

        private void GetItem()
        {
            string query = "select * from items";
            DataTable dt = new DataTable();
            dt = sqldb.GetDataTable(query);
            grvItem.DataSource = dt;
            grvItem.DataBind();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "insert into items(item_name,HSN_SACCode,taxper,Company,ItemGroup,salePrice,MRP,Purchase,waranty,toitems) values" +
                    "('" + itemName.Text + "'," +
                    "'" + txthsncode.Text + "'," +
                    "'" + Tax.Text + "'," +
                    "'" + Company.Text + "'," +
                    "'" + Group.SelectedItem.Text + "'," +
                    "'" + SalesPrice.Text + "'" +
                    ",'" + MRP.Text + "'," +
                    "'" + Purchase.Text + "'," +
                    "'" + txtWarranty.Text + "','0')";
                int ret = 0;
                ret = sqldb.excuteSql(query);
                if (ret > 0)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('New Item Added');", true);
                    // AddItemDiv.Visible = false;
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('something error');", true);
                }


            }
            catch (Exception ex)
            {
            }
        }
    }
}