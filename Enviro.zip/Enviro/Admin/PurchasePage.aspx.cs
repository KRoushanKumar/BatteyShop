﻿
using CCSBMS.App_code;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace CCSBMS.Admin
{
    public partial class PurchasePage : System.Web.UI.Page
    {
        db sqldb = new db();
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (Session["ID"] != null)
            {
                if (!IsPostBack == true)
                {
                    GetItem();
                    GetPurchase();
                    getdefaultdate();
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please Login..., You are automatic redirect at User Login Window.'); window.location.href = '../Default.aspx';", true);
            }
        }
        private void getdefaultdate()
        {
            DateTime dt = DateTime.Now;
            txtpurdate.Text = dt.ToShortDateString();
           // dt = dt.AddDays(5);
          //  txtpurdate.Text = dt.ToShortDateString();


        }
        private void GetPurchase()
        {
            string query = "select convert(varchar(255),p.Pur_Date,103) as 'Purchase Date', i.item_name as 'Item Name',p.QtyPic as 'Quanity' ,p.NetValue,p.WarrantyMonths as Warranty  from P_Purchase p left join items i on p.Item_ID=i.id ";
            DataTable dt = new DataTable();
            dt = sqldb.GetDataTable(query);
            grvItem.DataSource = dt;
            grvItem.DataBind();
        }

        private void GetItem()
        {
            string query = "select '0' as Id, '-Select Items-' as Name Union All select Id,item_name as Name from items";
            DataTable dt = new DataTable();
            dt = sqldb.GetDataTable(query);
            if (dt.Rows.Count > 0)
            {
                DDLItem.DataSource = dt;
                DDLItem.DataTextField = "Name";
                DDLItem.DataValueField = "ID";
                DDLItem.DataBind();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToInt32(txtqty.Text) == ListSerailNo.Items.Count)
                {
                    //string query = "insert into P_purchase(Pur_Date,Item_ID  " +
                    //    ",WarrantyMonths  ,QtyPic," +
                    //    "SalesPrice ,MRP ,Purchase ," +
                    //    "Disc  ,TaxAmt ,NetValue,status) values" +
                    //    "('" + Convert.ToDateTime(txtpurdate.Text).ToString("yyyy/MM/dd ") + "'," +
                    //    "'" + DDLItem.SelectedValue.ToString() + "'," +
                    //    "'" + txtWarranty.Text + "'," +
                    //    "'" + Convert.ToInt32(txtqty.Text) + "'," +
                    //    "'" + txtSalesPrice.Text + "'," +
                    //    "'" + txtMRP.Text + "'," +
                    //    "'" + txtPurchase.Text + "'," +
                    //    "'" + txtdisper.Text + "'," +
                    //    "'" + txtTaxAmt.Text + "'," +
                    //    "'" + txtTaxAmt.Text + "'," +
                    //    "'A') " +
                    //    "update items set toitems=(items.toitems + " + Convert.ToInt32(txtqty.Text) + " )  where id=" + DDLItem.SelectedValue.ToString() + " ";
                    int ret = 0;
                    ArrayList _alCRUD = new ArrayList();
                    SP.spArgumentsCollection(_alCRUD, "@Ret", "0", "Int", "O");
                    SP.spArgumentsCollection(_alCRUD, "@Pur_Date", Convert.ToDateTime(txtpurdate.Text).ToString("yyyy/MM/dd"), "datetime", "I");
                    SP.spArgumentsCollection(_alCRUD, "@Item_ID", DDLItem.SelectedValue.ToString(), "varchar", "I");
                    SP.spArgumentsCollection(_alCRUD, "@WarrantyMonths", txtWarranty.Text, "varchar", "I");
                    SP.spArgumentsCollection(_alCRUD, "@QtyPic", Convert.ToInt32(txtqty.Text).ToString(), "Int", "I");
                    SP.spArgumentsCollection(_alCRUD, "@SalesPrice", txtSalesPrice.Text, "varchar", "I");
                    SP.spArgumentsCollection(_alCRUD, "@MRP", txtMRP.Text, "varchar", "I");
                    SP.spArgumentsCollection(_alCRUD, "@Purchase", txtPurchase.Text, "varchar", "I");
                    SP.spArgumentsCollection(_alCRUD, "@Disc", txtdisper.Text, "varchar", "I");
                    SP.spArgumentsCollection(_alCRUD, "@TaxAmt", txtTaxAmt.Text, "varchar", "I");
                    SP.spArgumentsCollection(_alCRUD, "@NetValue", txtNetValue.Text, "varchar", "I");
                    SP.spArgumentsCollection(_alCRUD, "@status", "A", "char", "I");

   

                    ret = SP.RunStoredProcedureWithReturn("sp_setpurchase", _alCRUD);

                    foreach (ListItem srn in ListSerailNo.Items)
                    {
                        string querys = "insert into item_serialNo(ItemId,SerialNo,status,PurchaseDate,purchaseId,CHSNSTATUS) values('" + DDLItem.SelectedValue.ToString() + "','" + srn + "','A','" + Convert.ToDateTime(txtpurdate.Text).ToString("yyyy/MM/dd ") + "','"+ret+"','A')";
                        sqldb.excuteSql(querys);
                    }

                    if (ret > 0)
                    {
                        ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Done');window.location.href = 'PurchasePage.aspx';", true);
                        GetPurchase();
                        clear();
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('something error');", true);
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Add  Serial No');", true);
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + ex.Message + "');", true);
            }

        }

        protected void DDLItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string query = "select Id,item_name as Name,shortName,taxper,Company,ItemGroup,salePrice,MRP,Purchase,waranty from items where id='" + DDLItem.SelectedValue.ToString() + "'";
                DataTable dt = new DataTable();
                dt = sqldb.GetDataTable(query);
                if (dt.Rows.Count > 0)
                {
                 //   ShortName.Text = dt.Rows[0]["shortName"].ToString();
                    txtMRP.Text = dt.Rows[0]["MRP"].ToString();
                  //  Group.Text = dt.Rows[0]["ItemGroup"].ToString();
                    txtSalesPrice.Text = dt.Rows[0]["salePrice"].ToString();
                    txtPurchase.Text = dt.Rows[0]["Purchase"].ToString();
                    txtWarranty.Text = dt.Rows[0]["waranty"].ToString();
                    txtTaxAmt.Text = dt.Rows[0]["taxper"].ToString();
                 //   Company.Text = dt.Rows[0]["Company"].ToString();
                }
                dt.Clear();
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + ex.Message + "');", true);
            }
        }

        protected void txtqty_TextChanged(object sender, EventArgs e)
        {
            try
            {
                txtserial.Enabled = true;
                int qty = 0;
                double pur = 0.00, disc = 0.00, gst = 0.00, netvalue = 0.00;

                if (txtqty.Text == "")
                {
                    qty = 0;
                }
                else
                {
                    qty = Convert.ToInt32(txtqty.Text);

                }

                if (txtPurchase.Text == "")
                {
                    pur = 0.0;
                }
                else
                {
                    try
                    {
                        pur = Convert.ToDouble(Convert.ToInt32(txtPurchase.Text));
                    }
                    catch
                    {
                        pur = Convert.ToDouble(txtPurchase.Text);
                    }

                }


                if (txtdisper.Text == "")
                {
                    disc = 0.0;
                }
                else
                {
                    try
                    {
                        disc = Convert.ToDouble(Convert.ToInt32(txtdisper.Text));
                    }
                    catch
                    {
                        disc = Convert.ToDouble(txtdisper.Text);
                    }


                }

                if (txtTaxAmt.Text == "")
                {
                    gst = 0.0;
                }
                else
                {
                    try
                    {
                        gst = Convert.ToDouble(Convert.ToInt32(txtTaxAmt.Text));
                    }
                    catch
                    {
                        gst = Convert.ToDouble(txtTaxAmt.Text);
                    }

                }



                netvalue = (qty * pur) * ((100 - disc) / 100) * ((100 + gst) / 100);

                txtNetValue.Text = netvalue.ToString();
            }
            catch (Exception ex)
            {

            }

        }

        protected void btnserialadd_Click(object sender, EventArgs e)
        {

            try
            {
                
                string query = "select * from item_serialNo WHERE SerialNo='"+ txtserial.Text + "'";
                DataTable dt = new DataTable();
                dt = sqldb.GetDataTable(query);
                if (dt.Rows.Count > 0)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('This serial no  is already exists. ');", true);

                }
                else
                {
                    int ctr = Convert.ToInt32(txtqty.Text);
                    if (ctr > ListSerailNo.Items.Count)
                    {

                        txtserial.Enabled = true;

                        if (txtserial.Text == "")
                            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Input Serail No');", true);
                        else
                        {

                            int fl = 0;
                            foreach(ListItem l in ListSerailNo.Items)
                            {
                                if(txtserial.Text==l.ToString())
                                {
                                    fl++;
                                    break;
                                }
                            }
                            if (fl>0)
                                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('already added Serail No');", true);
                            else
                                ListSerailNo.Items.Add(txtserial.Text.Trim());
                        }
                        totalserailno.Text = ListSerailNo.Items.Count.ToString();
                        txtserial.Text = "";
                    }
                    else
                    {
                        txtserial.Enabled = false;
                    }
                }
            }
            catch(Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + ex.Message + "'btnserialadd_Click,PurchasePage);", true);
            }
            
        }
        public void clear()
        {
            txtPurchase.Text = "";
            txtNetValue.Text = "";
            txtqty.Text = "";
            txtdisper.Text = "";
            txtMRP.Text = "";
            txtSalesPrice.Text = "";
            txtserial.Text = "";
            ListSerailNo.Items.Clear();
            txtWarranty.Text = "";
            GetItem();
            txtTaxAmt.Text = "";
          //  ShortName.Text = "";


        }

        protected void btnrefresh_Click(object sender, EventArgs e)
        {
            GetPurchase();
        }

        protected void btnrefresh_Click1(object sender, EventArgs e)
        {

        }

        protected void deletesn_Click(object sender, EventArgs e)
        {
            ListSerailNo.Items.Remove(ListSerailNo.SelectedItem);
            txtserial.Enabled = true;
        }

        protected void BTNNEW_Click(object sender, EventArgs e)
        {
            getdefaultdate();
        }

        protected void bydatefil_Click(object sender, EventArgs e)
        {
            string query = "select convert(varchar(255),p.Pur_Date,103) as 'Purchase Date', i.item_name as 'Item Name',p.QtyPic as 'Quanity' ,p.NetValue,p.WarrantyMonths as Warranty  from P_Purchase p left join items i on p.Item_ID=i.id WHERE Pur_Date BETWEEN '" + Convert.ToDateTime(SDATE.Text).ToString("yyyy/MM/dd ") + "'  AND '" + Convert.ToDateTime(EDATE.Text).ToString("yyyy/MM/dd ") + "'  ";
            DataTable dt = new DataTable();
            dt = sqldb.GetDataTable(query);
            grvItem.DataSource = dt;
            grvItem.DataBind();
        }
    }
}