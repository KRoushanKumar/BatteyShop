﻿
using CCSBMS.App_code;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CCSBMS.Admin
{
    public partial class salesPage : System.Web.UI.Page
    {
        db sqldb = new db();
       
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack == true)
                {
                    cousterDiv.Visible = false;
                    GetItem();
                    getCostomer();
                    Session["Q"] = "";
                    // GetPurchase();

                }
               // GetItem();
               // clearText();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please Login..., You are automatic redirect at User Login Window.'); window.location.href = '../Default.aspx';", true);
            }
        }

        private void getCostomer()
        {
            string query = "select '0' as Id,'-select Name-' as Name union all select  Id,CName as Name from cousterDetails";
            DataTable dt = new DataTable();
            dt = sqldb.GetDataTable(query);
            if (dt.Rows.Count > 0)
            {
                ddlcustomer.DataSource = dt;
                ddlcustomer.DataTextField = "Name";
                ddlcustomer.DataValueField = "ID";
                ddlcustomer.DataBind();
                
            }
        }

        private void clearText()
        {
            

                txtNetValue.Text = "";
                txtqty.Text = "";
           // txtSerialNo.Text = "";
            txtNetValue.Text = "";
                txtMRP.Text = "";
                txtSalesPrice.Text = "";


                txtWarranty.Text = "";
                GetItem();
            getCostomer();
            txtmob2.Text = "";



            
        }

        private void GetItem()
        {
            string query = "select '0' as Id,'-select Item-' as Name union all select  Id,item_name as Name from items";
            DataTable dt = new DataTable();
            dt = sqldb.GetDataTable(query);
            if (dt.Rows.Count > 0)
            {
                DDLItem.DataSource = dt;
                DDLItem.DataTextField = "Name";
                DDLItem.DataValueField = "ID";
                DDLItem.DataBind();
                
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dtitems = new DataTable();
                dtitems.Columns.Add("ItemId", typeof(string));
                dtitems.Columns.Add("Qty", typeof(string));
                dtitems.Columns.Add("salesPrice", typeof(string));
                dtitems.Columns.Add("SerialNo", typeof(string));
                dtitems.Columns.Add("Dis", typeof(string));
                dtitems.Columns.Add("DisAmount", typeof(double));
                dtitems.Columns.Add("SGST", typeof(string));
                dtitems.Columns.Add("CGST", typeof(string));
                dtitems.Columns.Add("IGST", typeof(string));
                dtitems.Columns.Add("GstAmount", typeof(double));
                if (grvItem.Rows.Count > 0)
                {
                    foreach (GridViewRow row in grvItem.Rows)
                    {
                        DataRow dr1 = dtitems.NewRow();
                        for (int i = 0; i < row.Cells.Count; i++)
                            dr1[i] = row.Cells[i].Text;
                        dtitems.Rows.Add(dr1);
                    }
                }
                int ret = 0;

                ArrayList _alCRUD = new ArrayList();
                SP.spArgumentsCollection(_alCRUD, "@Ret", "0", "Int", "O");
                SP.spArgumentsCollection(_alCRUD, "@Sales_Date", Convert.ToDateTime(txtsalsdate.Text).ToString("yyyy/MM/dd"), "datetime", "I");
                SP.spArgumentsCollection(_alCRUD, "@CusName", Session["CID"].ToString(), "varchar", "I");
                SP.spArgumentsCollection(_alCRUD, "@DiscAmt", ViewState["TolDisAmt"].ToString(), "varchar", "I");
                SP.spArgumentsCollection(_alCRUD, "@gst", ViewState["TolGstAmt"].ToString(), "varchar", "I");
                SP.spArgumentsCollection(_alCRUD, "@NetValue", ViewState["ToNetAmt"].ToString(), "varchar", "I");
                SP.spArgumentsCollection(_alCRUD, "@status", "A", "char", "I");
                SP.spArgumentsCollection(_alCRUD, "@TranportMode", txtTranportMode.Text, "varchar", "I");
                SP.spArgumentsCollection(_alCRUD, "@vehicleNo", txtvehicleNo.Text, "varchar", "I");
                SP.spArgumentsCollection(_alCRUD, "@placeOfSupply", txtplaceOfSupply.Text, "varchar", "I");
                SP.spArgumentsCollection(_alCRUD, "@state", txtstate.Text, "varchar", "I");
                SP.spArgumentsCollection(_alCRUD, "@pincode", txtpincode.Text, "varchar", "I");

                ret = SP.RunStoredProcedureWithReturn("sp_setCustomerDetails", _alCRUD);

                if (ret > 0)
                {


                    for (int i = 0; i < dtitems.Rows.Count; i++)
                    {
                        string qu = "insert into S_sales_ProductDetails" +
                            "(QtyPic," +
                            "salesPrice," +
                            "SerialNo," +

                            "Discper," +
                            "DiscAmt," +
                            "CGST," +
                            "SGST," +
                            "IGST," +
                            "gstamt," +
                            "CustomerId," +
                            "salesDate," +
                            "Item_ID," +
                            "status) " +
                            "values" +
                            "('" + dtitems.Rows[i]["Qty"].ToString() + "'," +
                            "'" + dtitems.Rows[i]["salesPrice"].ToString() + "'," +
                            "'" + dtitems.Rows[i]["SerialNo"].ToString() + "'," +

                            "'" + dtitems.Rows[i]["Dis"].ToString() + "'," +
                            "'" + dtitems.Rows[i]["DisAmount"].ToString() + "'," +
                            "'" + dtitems.Rows[i]["CGST"].ToString() + "'," +
                            "'" + dtitems.Rows[i]["SGST"].ToString() + "'," +
                            "'" + dtitems.Rows[i]["IGST"].ToString() + "'," +
                            "'" + dtitems.Rows[i]["GstAmount"].ToString() + "'," +
                            "'" +ret + "'," +
                            "'" + Convert.ToDateTime(txtsalsdate.Text).ToString("yyyy/MM/dd") + "'," +
                         //no erase
                            "'" + dtitems.Rows[i]["ItemId"].ToString() + "'," +
                            "'A') " +
                            "update item_serialNo set status='S' where SerialNo='" + dtitems.Rows[i]["SerialNo"].ToString() + "' " +
                            "update items set toitems=(items.toitems - 1)  where id='" + dtitems.Rows[i]["ItemId"].ToString() + "' ";
                        sqldb.excuteSql(qu);

                        try
                        {
                            string q = "update chalan_cusdets set status = 'D' where id='"+ Session["ChalanNo"].ToString() + "' " +
                                "update chalan_s_prodets set status = 'D' where CustomerId = '" + Session["ChalanNo"].ToString() + "'";
                            sqldb.excuteSql(q);
                        }
                        catch
                        { }
                    }

                    
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Done');window.location.href = 'SalesReport.aspx';", true);
                   // clearText();
                   // PrintBill();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('something error');", true);
                }
            }
            catch (Exception ex)
            {
            }
        }

        private void PrintBill()
        {
          
        }

        protected void DDLItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                string query = "select Id,item_name as Name,taxper,Company,ItemGroup,salePrice,MRP,Purchase,waranty from items where id='" + DDLItem.SelectedValue.ToString() + "'";
                DataTable dt = new DataTable();
                dt = sqldb.GetDataTable(query);
                if (dt.Rows.Count > 0)
                {
                    // ShortName.Text = dt.Rows[0]["shortName"].ToString();
                    txtMRP.Text = dt.Rows[0]["MRP"].ToString();
                    Group.Text = dt.Rows[0]["ItemGroup"].ToString();
                    txtSalesPrice.Text = dt.Rows[0]["salePrice"].ToString();

                    txtWarranty.Text = dt.Rows[0]["waranty"].ToString();
                    txtsgst.Text = (Convert.ToInt32(dt.Rows[0]["taxper"].ToString()) / 2).ToString();
                    txtcgst.Text = (Convert.ToInt32(dt.Rows[0]["taxper"].ToString()) / 2).ToString();
                }
                dt.Clear();
                GetRemaningSerialNO();
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('"+ex.Message+"');", true);
            }
        }

        private void GetRemaningSerialNOADD()
        {

            Session["Q"] = Session["Q"].ToString() + "and SerialNo <> '"+DDlserialNo.SelectedItem.ToString()+"' ";
            string getSerial = "select SerialNo as Name , ID from item_serialNo where  status='A' and itemid='" + DDLItem.SelectedValue.ToString() + "'  "+Session["Q"].ToString()+" ";
            DataTable dtserali = new DataTable();
            dtserali = sqldb.GetDataTable(getSerial);
            if (dtserali.Rows.Count >= 0)
            {
                DDlserialNo.DataSource = dtserali;
                DDlserialNo.DataTextField = "Name";
                DDlserialNo.DataValueField = "ID";
                DDlserialNo.DataBind();

            }
            else
            {

            }
            dtserali.Clear();
        }

        public void GetRemaningSerialNO()
        {
            try
            {

                string getSerial = "select SerialNo as Name , ID from item_serialNo where  status='A' and itemid='" + DDLItem.SelectedValue.ToString() + "' ";
                DataTable dtserali = new DataTable();
                dtserali = sqldb.GetDataTable(getSerial);
                if (dtserali.Rows.Count > 0)
                {
                    DDlserialNo.DataSource = dtserali;
                    DDlserialNo.DataTextField = "Name";
                    DDlserialNo.DataValueField = "ID";
                    DDlserialNo.DataBind();

                }
                dtserali.Clear();
            }
            catch(Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + ex.Message + "');", true);
            }
        }

        protected void btnAddSales_Click(object sender, EventArgs e)
        {
            try
            {
                //DataTable s_dt = new DataTable();
                //string query = " select * from item_serialNo where SerialNo = '"+DDlserialNo.SelectedItem.ToString()+"' and status = 'A' and itemid='"+DDLItem.SelectedValue.ToString()+"'";
                //s_dt = sqldb.getDataTable(query);
                //if (s_dt.Rows.Count > 0)
                //{


                    DataTable dt = new DataTable();
                    dt.Columns.Add("ItemId", typeof(string));
                    dt.Columns.Add("Qty", typeof(string));
                    dt.Columns.Add("salesPrice", typeof(string));
                    dt.Columns.Add("SerialNo", typeof(string));
                    //dt.Columns.Add("BasicPrice", typeof(string));
                    dt.Columns.Add("Dis", typeof(string));
                    dt.Columns.Add("DisAmount", typeof(double));
                    dt.Columns.Add("SGST", typeof(string));
                    dt.Columns.Add("CGST", typeof(string));
                    dt.Columns.Add("IGST", typeof(string));
                    dt.Columns.Add("GstAmount", typeof(double));

                    if (grvItem.Rows.Count > 0)
                    {
                        foreach (GridViewRow row in grvItem.Rows)
                        {
                            DataRow dr1 = dt.NewRow();
                            for (int i = 0; i < row.Cells.Count; i++)
                                dr1[i] = row.Cells[i].Text;
                            dt.Rows.Add(dr1);
                        }
                    }


                    DataRow dr = dt.NewRow();
                    dr["ItemId"] = DDLItem.SelectedValue.ToString();
                    dr["Qty"] = txtqty.Text;
                    dr["salesPrice"] = txtSalesPrice.Text;
                    dr["SerialNo"] = DDlserialNo.SelectedItem.ToString();
                    //dr["BasicPrice"] = txtqty.Text;
                    dr["Dis"] = txtdisper1.Text;
                    dr["DisAmount"] = Convert.ToDouble(ViewState["disamount"]);
                    ViewState["TolDisAmt"] = Convert.ToDouble(ViewState["TolDisAmt"]) + Convert.ToDouble(ViewState["disamount"]);

                    dr["SGST"] = txtsgst.Text;
                    dr["CGST"] = txtcgst.Text;
                    dr["IGST"] = txtigst.Text;
                    dr["GstAmount"] = Convert.ToDouble(ViewState["gstamount"]);
                    ViewState["TolGstAmt"] = Convert.ToDouble(ViewState["TolGstAmt"]) + Convert.ToDouble(ViewState["gstamount"]);
                    ViewState["ToNetAmt"] = Convert.ToDouble(ViewState["ToNetAmt"]) + Convert.ToDouble(ViewState["NetAmt"]);
                    LTOTAL.Text = ViewState["ToNetAmt"].ToString();
                    Ldis.Text = ViewState["TolDisAmt"].ToString();
                    lgst.Text = ViewState["TolGstAmt"].ToString();
                    dt.Rows.Add(dr);

                    grvItem.DataSource = dt;
                    grvItem.DataBind();
                GetRemaningSerialNOADD();
                //}
                //else
                //{
                //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('This Serial No Does Not Exist')", true);
                //}
            }
            catch(Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + ex.Message + " No Serial No');", true);
            }


        }

        protected void txtqty_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int qty = 0;
                double price = 0.0, sals = 0.0, disc = 0.00, sgst = 0.00, cgst = 0.00, igst = 0.00, netvalue = 0.00;

                if (txtqty.Text == "")
                    qty = 0;
                else
                    qty = Convert.ToInt32(txtqty.Text);

                if (txtSalesPrice.Text == "")
                    sals = 0.0;
                else
                {
                    try
                    {
                        sals = Convert.ToDouble(Convert.ToInt32(txtSalesPrice.Text));
                    }
                    catch
                    {
                        sals = Convert.ToDouble(txtSalesPrice.Text);
                    }


                }
                if (txtdisper1.Text == "")
                    disc = 0.0;
                else
                {
                    try
                    {
                        disc = Convert.ToDouble(Convert.ToInt32(txtdisper1.Text));
                    }
                    catch
                    {
                        disc = Convert.ToDouble(txtdisper1.Text);
                    }


                }

                if (txtsgst.Text == "")
                {
                    sgst = 0.0;
                }
                else
                {
                    try
                    {
                        sgst = Convert.ToDouble(Convert.ToInt32(txtsgst.Text));
                    }
                    catch
                    {
                        sgst = Convert.ToDouble(txtsgst.Text);
                    }

                }
                if (txtcgst.Text == "")
                {
                    cgst = 0.0;
                }
                else
                {
                    try
                    {
                        cgst = Convert.ToDouble(Convert.ToInt32(txtcgst.Text));
                    }
                    catch
                    {
                        cgst = Convert.ToDouble(txtcgst.Text);
                    }

                }
                if (txtigst.Text == "")
                {
                    igst = 0.0;
                }
                else
                {
                    try
                    {
                        igst = Convert.ToDouble(Convert.ToInt32(txtigst.Text));
                    }
                    catch
                    {
                        igst = Convert.ToDouble(txtigst.Text);
                    }

                }

                price = qty * sals;
                ViewState["disamount"] = (price) * ((disc) / 100);
                ViewState["gstamount"] = (price - Convert.ToDouble(ViewState["disamount"])) * ((sgst + cgst + igst) / 100);
                price = (price - Convert.ToDouble(ViewState["disamount"])) + Convert.ToDouble(ViewState["gstamount"]);
                netvalue = price;
                ViewState["NetAmt"] = netvalue;

                txtNetValue.Text = netvalue.ToString();
                txtBasicPrice.Text = (qty * sals).ToString();
            }
            catch (Exception ex)
            {

            }

        }

        protected void Unnamed_Click(object sender, ImageClickEventArgs e)
        {
            cousterDiv.Visible = true;
        }

        protected void addcustomer_Click(object sender, EventArgs e)
        {
            int ret = 0;
            ArrayList _alCRUD = new ArrayList();
    
            SP.spArgumentsCollection(_alCRUD, "@CusName", txtcust.Text, "varchar", "I");
            SP.spArgumentsCollection(_alCRUD, "@MobNo", txtmob.Text, "varchar", "I");

            SP.spArgumentsCollection(_alCRUD, "@Address", Txtaddress.Text, "varchar", "I");
            SP.spArgumentsCollection(_alCRUD, "@GstNo",txtCusGstNo.Text, "varchar", "I");
            SP.spArgumentsCollection(_alCRUD, "@status", "A", "char", "I");

             SP.RunStoredProcedure("sp_setAddCustomerDetails", _alCRUD);
            getCostomer();
            cousterDiv.Visible = false;
        }

        protected void closeCustomer_Click(object sender, EventArgs e)
        {
            cousterDiv.Visible = false;
        }

        protected void ddlcustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                string query = "select  Id,CName as Name,mob,address from cousterDetails where id='" + ddlcustomer.SelectedValue.ToString()+"'";
                DataTable dt = new DataTable();
                dt = sqldb.GetDataTable(query);
                if (dt.Rows.Count > 0)
                {
                    txtmob2.Text = dt.Rows[0]["mob"].ToString();
                  //  Session["CNAME"] = dt.Rows[0]["Name"].ToString();
                  //  Session["CADDRESS"] = dt.Rows[0]["address"].ToString();
                    Session["CID"] = dt.Rows[0]["Id"].ToString();
                }
            }
            catch(Exception ex)
            {

            }
                    
        }

        protected void BTNChalan_Click(object sender, EventArgs e)
        {
            try
            {
                Session["ChalanNo"] = txtchalanNo.Text;
                string query = "select  c.Id,c.CName as Name,c.mob,c.address from cousterDetails c  left join  chalan_cusdets cc on cc.CusName=c.id  where cc.id='" + txtchalanNo.Text + "' and cc.status='A'";
                DataTable dt = new DataTable();
                dt = sqldb.GetDataTable(query);
                if (dt.Rows.Count > 0)
                {
                    txtmob2.Text = dt.Rows[0]["mob"].ToString();
                    //  Session["CNAME"] = dt.Rows[0]["Name"].ToString();
                    //  Session["CADDRESS"] = dt.Rows[0]["address"].ToString();
                    Session["CID"] = dt.Rows[0]["Id"].ToString();
                    ddlcustomer.SelectedItem.Text= dt.Rows[0]["Name"].ToString();
                    //ViewState["TolDisAmt"] = dt.Rows[0]["DiscAmt"].ToString();
                    //ViewState["TolGstAmt"] = dt.Rows[0]["gst"].ToString();
                    //ViewState["ToNetAmt"] = dt.Rows[0]["netvalue"].ToString();
                    //LTOTAL.Text = ViewState["ToNetAmt"].ToString();
                    //Ldis.Text = ViewState["TolDisAmt"].ToString();
                    //lgst.Text = ViewState["TolGstAmt"].ToString();

                }
                DataTable dtamt = new DataTable();
                ArrayList _alCRUD = new ArrayList();

                SP.spArgumentsCollection(_alCRUD, "@chno", Session["ChalanNo"].ToString(), "Int", "I");
                SP.spArgumentsCollection(_alCRUD, "@status", "A", "char", "I");
                SP.RunStoredProcedure(dtamt, "getchalnaAmtDet", _alCRUD);
                if (dtamt.Rows.Count > 0)
                {
                    ViewState["TolDisAmt"] = dtamt.Rows[0]["DisAmt"].ToString();
                    ViewState["TolGstAmt"] = dtamt.Rows[0]["GSTamt"].ToString();
                    ViewState["ToNetAmt"] = dtamt.Rows[0]["Net Value"].ToString();
                    LTOTAL.Text = dtamt.Rows[0]["Net Value"].ToString();
                    Ldis.Text = dtamt.Rows[0]["DisAmt"].ToString();
                    lgst.Text = dtamt.Rows[0]["GSTamt"].ToString();
                }

                string query2 = "select c.item_id as   ItemId , c.qtypic as Qty, c.salesprice as salesPrice, c.serialNo as SerialNo ,c.discper as Dis, c.discamt as DisAmount , c.sgst as SGST, c.cgst as CGST, c.igst as IGST, c.gstamt as GstAmount from chalan_s_prodets c where c.CustomerID='" + txtchalanNo.Text + "' and c.status='A'";
                DataTable dttt = new DataTable();
                dttt = sqldb.GetDataTable(query2);
                if (dttt.Rows.Count > 0)
                {
                    grvItem.DataSource = dttt;
                    grvItem.DataBind();
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}