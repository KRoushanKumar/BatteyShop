﻿using CCSBMS.App_code;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CCSBMS.Admin
{
    public partial class SalesReport : System.Web.UI.Page
    {
        db sqldb = new db();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack == true)
                {

                    GetSalesDetails();

                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please Login..., You are automatic redirect at User Login Window.'); window.location.href = '../Default.aspx';", true);
            }
        }

        private void GetSalesDetails()
        {
            try
            {
                DataTable dt = new DataTable();
                ArrayList _alCRUD = new ArrayList();

                SP.spArgumentsCollection(_alCRUD, "@InvoiceNo",txtinvoiceNo.Text, "Varchar", "I");
                SP.RunStoredProcedure(dt, "Get_salesdetails", _alCRUD);
                if (dt.Rows.Count > 0)
                {
                    grvItem.DataSource = dt;
                    grvItem.DataBind();
                }
            }
            catch(Exception ex)
            {

            }
        }

        protected void grvItem_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                int index = 0, ret = 0;

                DataTable dtdlt = new DataTable();
                index = Convert.ToInt32(e.CommandArgument);
                if (e.CommandName == "cniprint")
                {
                    Session["Invoice"] = grvItem.Rows[index].Cells[4].Text;

                    Response.Redirect("salesPrint.aspx");


                }
            }
            catch (Exception Ex)
            {

            }
        }

        protected void BTNNEW_Click(object sender, EventArgs e)
        {
            
        }


        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
               server control at run time. */
        }

        protected void ExportToExcel(object sender, EventArgs e)
        {
            try
            {
                Response.Clear();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.ms-excel";
                using (StringWriter sw = new StringWriter())
                {
                    HtmlTextWriter hw = new HtmlTextWriter(sw);

                    //To Export all pages
                    grvItem.AllowPaging = false;
                    this.GetSalesDetailsexport();
                    try
                    {
                        grvItem.HeaderRow.BackColor = System.Drawing.Color.White;
                    }
                    catch
                    {

                    }
                    try
                    {
                        foreach (TableCell cell in grvItem.HeaderRow.Cells)
                        {
                            cell.BackColor = grvItem.HeaderStyle.BackColor;
                        }
                    }
                    catch
                    {

                    }
                    foreach (GridViewRow row in grvItem.Rows)
                    {
                        row.BackColor = System.Drawing.Color.White;
                        foreach (TableCell cell in row.Cells)
                        {
                            if (row.RowIndex % 2 == 0)
                            {
                                cell.BackColor = grvItem.AlternatingRowStyle.BackColor;
                            }
                            else
                            {
                                cell.BackColor = grvItem.RowStyle.BackColor;
                            }
                            cell.CssClass = "textmode";
                        }
                    }

                    grvItem.RenderControl(hw);

                    //style to format numbers to string
                    string style = @"<style> .textmode { } </style>";
                    Response.Write(style);
                    Response.Output.Write(sw.ToString());
                    Response.Flush();
                    Response.End();
                }
            }
            catch
            {

            }
        }

        private void GetSalesDetailsexport()
        {
            try
            {
                DataTable dt = new DataTable();
                ArrayList _alCRUD = new ArrayList();

                SP.spArgumentsCollection(_alCRUD, "@InvoiceNo", txtinvoiceNo.Text, "Varchar", "I");
                SP.RunStoredProcedure(dt, "Get_salesdetails", _alCRUD);
                if (dt.Rows.Count > 0)
                {
                    grvItem.DataSource = dt;
                    grvItem.DataBind();
                    sqldb.SetGridRowVisible(grvItem,"1,2");
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}