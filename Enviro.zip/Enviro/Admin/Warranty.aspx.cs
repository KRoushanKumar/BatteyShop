﻿using CCSBMS.App_code;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CCSBMS.Admin
{
    public partial class Warranty : System.Web.UI.Page
    {
        db sqldb = new db();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack == true)
                {

                    ReturnItemDiv.Visible = false;

                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please Login..., You are automatic redirect at User Login Window.'); window.location.href = '../Default.aspx';", true);
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = new DataTable();
                ArrayList _alCRUD = new ArrayList();
                Session["warrPrint"] = txtserialNo.Text;
                SP.spArgumentsCollection(_alCRUD, "@serialNo", txtserialNo.Text, "Varchar", "I");
                SP.RunStoredProcedure(dt, "GEt_warrantyStatus", _alCRUD);
                if (dt.Rows.Count > 0)
                {
                    grvItem.DataSource = dt;
                    grvItem.DataBind();
                }
            }
            catch (Exception ex)
            {

            }
        }
        protected void grvItems_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                int index = 0, ret = 0;
          
                DataTable dtdlt = new DataTable();
                index = Convert.ToInt32(e.CommandArgument);
                if (e.CommandName == "cnreplace")
                {
                    Session["oldSerailNo"] = grvItem.Rows[index].Cells[3].Text;
                    Session["RSNo"]= grvItem.Rows[index].Cells[5].Text;
                    if(Session["RSNo"].ToString()== "&nbsp;")
                    {
                        Session["RSNo"] = Session["oldSerailNo"].ToString();
                    }
                    Session["IID"] = grvItem.Rows[index].Cells[4].Text;
                    ReturnItemDiv.Visible = true;
                    warrantyDiv.Visible = false;

                    getRemaningserialno();
                }
            }
            catch (Exception Ex)
            {
                
            }
        }
       public void getRemaningserialno()
        {
            try
            {

                string getSerial = "select SerialNo as Name , ID from item_serialNo where  status='A' and itemid='" + Session["IID"].ToString() + "' ";
                DataTable dtserali = new DataTable();
                dtserali = sqldb.GetDataTable(getSerial);
                if (dtserali.Rows.Count > 0)
                {
                    ddlserialNo.DataSource = dtserali;
                    ddlserialNo.DataTextField = "Name";
                    ddlserialNo.DataValueField = "ID";
                    ddlserialNo.DataBind();

                }
                dtserali.Clear();
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + ex.Message + "');", true);
            }
        }
        protected void BtnReplace_Click(object sender, EventArgs e)
        {
            try
            {   
                if(ifsamesn.Checked)
                {
                    string query = "insert into replacement (IT_ID,SerialNo,ReSerialNo,ReDate,remarks,status) " +
                        "values('"+ Session["IID"].ToString() + "','"+ Session["oldSerailNo"] .ToString()+ "','" + Session["RSNo"].ToString() + "','" + Convert.ToDateTime(txtpurdate.Text).ToString("yyyy/MM/dd") + "','"+txtremarks.Text+"','A')";
                    //R For Replace
                    int re = sqldb.excuteSql(query);
                    if (re > 0)
                    {
                        ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Replace successfuly');window.location.href = 'Warranty.aspx';", true);
                    }
                    else
                    {

                    }
                }
                else
                {
                    string query = "update items set toitems=(items.toitems -1 )  where id=" + Session["IID"].ToString() + "" +
                    " update item_serialNo set status='R' where SerialNo='" + ddlserialNo.SelectedItem.ToString() + "' and ItemId=" + Session["IID"].ToString() + " ";

                    query += " insert into replacement (IT_ID,SerialNo,ReSerialNo,ReDate,remarks,status) " +
                        "values('" + Session["IID"].ToString() + "','" + Session["oldSerailNo"].ToString() + "','" + ddlserialNo.SelectedItem.ToString() + "','" + Convert.ToDateTime(txtpurdate.Text).ToString("yyyy/MM/dd") + "','" + txtremarks.Text + "','A')";
                    
                    //R For Replace
                    int re = sqldb.excuteSql(query);
                    if (re > 0)
                    {
                        ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Replace successfuly');window.location.href = 'Warranty.aspx';", true);
                    }
                    else
                    {

                    }
                }

            }
            catch
            {

            }
        }

        protected void btnreClose_Click(object sender, EventArgs e)
        {
            ReturnItemDiv.Visible = false;
            warrantyDiv.Visible = true;
        }

        protected void ifsamesn_CheckedChanged(object sender, EventArgs e)
        {
            if (ddlserialNo.Enabled == true)
                ddlserialNo.Enabled = false;
            else
                ddlserialNo.Enabled = true;
        }

        protected void WarrPrint_Click(object sender, EventArgs e)
        {
            Response.Redirect("warrantyPrint.aspx");
        }
    }
}