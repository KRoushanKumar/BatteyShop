﻿
using CCSBMS.App_code;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace CCSBMS.Admin
{
    public partial class PurchaseReport : System.Web.UI.Page
    {
        db sqldb = new db();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack == true)
                {
                    GetItem();
                    GetToTalQuantityDetails();
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please Login..., You are automatic redirect at User Login Window.'); window.location.href = '../Default.aspx';", true);
            }
        }

        private void GetToTalQuantityDetails()
        {
            try
            {
                string query = "select item_name as Name,toitems As 'In Stock' from items  ";
                DataTable dt = new DataTable();
                dt = sqldb.GetDataTable(query);
                if (dt.Rows.Count > 0)
                {
                    //DDLItem.DataSource = dt;
                    //DDLItem.DataTextField = "Name";
                    //DDLItem.DataValueField = "ID";
                    //DDLItem.DataBind();
                    GridTotalItemsQuantity.DataSource = dt;
                    GridTotalItemsQuantity.DataBind();
                }
            }
            catch(Exception ex)
            {

            }
            
        }

        private void GetItem()
        {
            string query = "select '0' as Id, '-Select Items-' as Name Union All select Id,item_name as Name from items";
            DataTable dt = new DataTable();
            dt = sqldb.GetDataTable(query);
            if (dt.Rows.Count > 0)
            {
                DDLItem.DataSource = dt;
                DDLItem.DataTextField = "Name";
                DDLItem.DataValueField = "ID";
                DDLItem.DataBind();
            }
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {

        }

        protected void DDLItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = new DataTable();
                ArrayList _alCRUD = new ArrayList();

                SP.spArgumentsCollection(_alCRUD, "@ItemID", DDLItem.SelectedValue.ToString(), "Varchar", "I");
                SP.RunStoredProcedure(dt, "stocksDetails", _alCRUD);
                if (dt.Rows.Count > 0)
                {
                    grvItem.DataSource = dt;
                    grvItem.DataBind();
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}