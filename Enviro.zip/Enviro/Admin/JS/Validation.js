﻿var txtName
function onlyNos(e, t) {
   txtName = (t).getAttribute("ValidationType");


    try {
        if (txtName.toString() == "num") {
            return Isnumeric(e, t)
        }

        else if (txtName == "dec") {          
                
             return isdecimalKey(e, t)
         }
         else if (txtName == "money") {

             return isdecimalKey(e, t)
         }

        else {

        }


    }
    catch (err) {
        alert(err.Description);
    }
}


function Isnumeric(e, t) {
    try {
        if (window.event) {
            var charCode = window.event.keyCode;
        }
        else if (e) {
            var charCode = e.which;
        }
        else { return true; }
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            // alert(" Input digits (0 - 9)")  
            t.setAttribute("style", "color: red;");
            
            return false;
        }
        t.setAttribute("style", "color: Black;");
        return true;
    }
    catch (err) {
        alert(err.Description);
    }
}

function isdecimalKey(evt,t) {
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {

        t.setAttribute("style", "color: red;");
        return false;
    } else {
        t.setAttribute("style", "color: Black;");
        if (txtName == "money") {           
                if (charCode == 13 && charCode == 9) {
                    callajax();
                    moneyFormat(t);
                   t.blur();
                }            
            
            return true;
       }
       
           
       
    }
}
 
 function moneyFormat(e,t) {
    alert(1);
    var x = t.value ;
    x = x.toString();
    var afterPoint = '';
    if (x.indexOf('.') > 0)
        afterPoint = x.substring(x.indexOf('.'), x.length);
    x = Math.floor(x);
    x = x.toString();
    var lastThree = x.substring(x.length - 3);
    var otherNumbers = x.substring(0, x.length - 3);
    if (otherNumbers != '')
        lastThree = ',' + lastThree;
    var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree + afterPoint;

    t.value = res;
    
}

 




 
 function onlyNos(e, t)
    



 