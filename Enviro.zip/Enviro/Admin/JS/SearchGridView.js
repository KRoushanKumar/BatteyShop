﻿subinsblogla = 0;

//setInterval(function () {
//    if (document.readyState != 'complete') {

//        document.documentElement.style.overflow = "hidden";
//        var subinsblog = document.createElement("div");
//        subinsblog.id = "subinsblogldiv";
//        var polu = 99 * 99 * 99999999 * 999999999;
//        //subinsblog.style.zIndex = polu;
//        subinsblog.style.background = "white url(../images/wait.gif) 50% 50% no-repeat";
//        subinsblog.style.backgroundPositionX = "50%";
//        subinsblog.style.backgroundPositionY = "50%";
//        subinsblog.style.position = "absolute";
//        subinsblog.style.right = "0px";
//        subinsblog.style.left = "0px";
//        subinsblog.style.top = "0px";
//        subinsblog.style.bottom = "0px";
//        if (subinsblogla == 0) {
//            document.documentElement.appendChild(subinsblog);
//            subinsblogla = 1;
//        }
//    } else if (document.getElementById('subinsblogldiv') != null) {

//        document.getElementById('subinsblogldiv').style.display = "none";
//        document.documentElement.style.overflow = "auto";
//    }
//}, 100);
/*
$(document).ready(function () {
    // Setting focus on first textbox
    $('input:text:first').focus();
    // binding keydown event to textbox
    $('input:text').bind('keydown', function (e) {
        // detecting keycode returned from keydown and comparing if its equal to 13 (enter key code)
        if (e.keyCode == 13) {
            // by default if you hit enter key while on textbox so below code will prevent that default behaviour
            e.preventDefault();
            // getting next index by getting current index and incrementing it by 1 to go to next textbox
            var nextIndex = $('input:text').index(this) + 1;
            // getting total number of textboxes on the page to detect how far we need to go
            var maxIndex = $('input:text').length;
            // check to see if next index is still smaller then max index
            if (nextIndex < maxIndex) {
                // setting index to next textbox using CSS3 selector of nth child
                $('input:text:eq(' + nextIndex + ')').focus();
            }
        }
    });
});
*/


function Search_Gridview(strKey, strGV) {
    var strData = strKey.value.toLowerCase().split(" ");
    var tblData = document.getElementById(strGV);
    //alert(tblData);
    var rowData;
    for (var i = 1; i < tblData.rows.length; i++) {
        rowData = tblData.rows[i].innerHTML;
        var styleDisplay = 'none';
        for (var j = 0; j < strData.length; j++) {
            if (rowData.toLowerCase().indexOf(strData[j]) >= 0)
                styleDisplay = '';
            else {
                styleDisplay = 'none';
                break;
            }
        }
        tblData.rows[i].style.display = styleDisplay;
    }
}

function doPrint(strKey, strCtrl, strBranchNm, strRptName, strgrvCaption, logoImg) {
    var panel = document.getElementById(strCtrl);
    var imgpath = "../images/magadh.jpg";
    //var imgpath = "../images/" + document.getElementById(logoImg).value;
    var branchName = document.getElementById(strBranchNm).value;
    var reportName = document.getElementById(strRptName).value;
    var grvCaption = document.getElementById(strgrvCaption);
    grvCaption.style.display = 'none'; 
  
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!

    var yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd
    }
    if (mm < 10) {
        mm = '0' + mm
    }
    var today = dd + '/' + mm + '/' + yyyy;
    var printDate = "Date: " + today + "";

    
    var printWindow = window.open('', '', 'height=1000px,width=1000px,left=200');
    printWindow.document.write('<html>');
    printWindow.document.write('<body ><div style="width:650px; height:90px"><div style="width:100%; text-align:center; height:50px; font-size:19px; font-weight:bold"><div style="float:left"><img src = "../' + imgpath + '" height="50px" width="50px" /></div>' + branchName + '<div style="width:100%; text-align:center; height:20px;"> <div style="width:90%; height:20px; float:left; font-size:16px; font-weight:bold">' + reportName + '</div></div></div><hr /><div style="width:100%; text-align:right; height:20px;  font-size:12px;">' + printDate + '</div></div>  ');
    printWindow.document.write(panel.innerHTML);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.close();
    setTimeout(function () {
        printWindow.print();
    }, 500);

    grvCaption.style.display = 'block'; 
    return false;

}


function pPrintDiv(divName) {
    var divContents = document.getElementById("" + divName + "").innerHTML;
    var printWindow = window.open('', '', 'height=600px,width=800px');
    printWindow.document.write('<html><head>');
    printWindow.document.write('</head><body style="width:800px; height:600px;">');
    printWindow.document.write(divContents);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
    printWindow.close();
}


//---------------------------------------------------------------------------------------------------------------------------------------//
function OnTreeClick(evt) {
    var src = window.event != window.undefined ? window.event.srcElement : evt.target;
    var isChkBoxClick = (src.tagName.toLowerCase() == "input" && src.type == "checkbox");
    if (isChkBoxClick) {
        var parentTable = GetParentByTagName("table", src);
        var nxtSibling = parentTable.nextSibling;
        if (nxtSibling && nxtSibling.nodeType == 1)//check if nxt sibling is not null & is an element node
        {
            if (nxtSibling.tagName.toLowerCase() == "div") //if node has children
            {
                //check or uncheck children at all levels
                CheckUncheckChildren(parentTable.nextSibling, src.checked);
            }
        }
        //check or uncheck parents at all levels
        CheckUncheckParents(src, src.checked);
    }
}

function CheckUncheckChildren(childContainer, check) {
    var childChkBoxes = childContainer.getElementsByTagName("input");
    var childChkBoxCount = childChkBoxes.length;
    for (var i = 0; i < childChkBoxCount; i++) {
        childChkBoxes[i].checked = check;
    }
}

function CheckUncheckParents(srcChild, check) {
    var parentDiv = GetParentByTagName("div", srcChild);
    var parentNodeTable = parentDiv.previousSibling;

    if (parentNodeTable) {
        var checkUncheckSwitch;

        if (check) //checkbox checked
        {
            var isAllSiblingsChecked = AreAllSiblingsChecked(srcChild);
            if (isAllSiblingsChecked)
                checkUncheckSwitch = true;
            else
                return; //do not need to check parent if any(one or more) child not checked
        }
        else //checkbox unchecked
        {
            checkUncheckSwitch = false;
        }

        var inpElemsInParentTable = parentNodeTable.getElementsByTagName("input");
        if (inpElemsInParentTable.length > 0) {
            var parentNodeChkBox = inpElemsInParentTable[0];
            parentNodeChkBox.checked = checkUncheckSwitch;
            //do the same recursively
            CheckUncheckParents(parentNodeChkBox, checkUncheckSwitch);
        }
    }
}

function AreAllSiblingsChecked(chkBox) {
    var parentDiv = GetParentByTagName("div", chkBox);
    var childCount = parentDiv.childNodes.length;
    for (var i = 0; i < childCount; i++) {
        if (parentDiv.childNodes[i].nodeType == 1) //check if the child node is an element node
        {
            if (parentDiv.childNodes[i].tagName.toLowerCase() == "table") {
                var prevChkBox = parentDiv.childNodes[i].getElementsByTagName("input")[0];
                //if any of sibling nodes are not checked, return false
                if (!prevChkBox.checked) {
                    return false;
                }
            }
        }   
    }
    return true;
}

//utility function to get the container of an element by tagname
function GetParentByTagName(parentTagName, childElementObj) {
    var parent = childElementObj.parentNode;
    while (parent.tagName.toLowerCase() != parentTagName.toLowerCase()) {
        parent = parent.parentNode;
    }
    return parent;
}


//var prm = Sys.WebForms.PageRequestManager.getInstance();
//prm.add_pageLoaded(pageLoaded);
//prm.add_initializeRequest(initializeRequest);
//prm.add_endRequest(endRequest);

//---------------------------------------------------------------------------------------------------------------------------------------//