﻿using CCSBMS.App_code;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CCSBMS.Admin
{
    public partial class warrantyPrint : System.Web.UI.Page
    {
        db sqldb = new db();
        public string Name, gstno, address;
        public string CompanyGstno, CEmail, compaddress, CbankName, cbranch, cAcNo, cifstcode, Term1, term2, term3, term4, term5;

        protected void Page_Load(object sender, EventArgs e)
        {
            print();
            getcousterdetails();
            getCompanyDetails();
        }

        private void getcousterdetails()
        {
            try
            {
                DataTable dt = new DataTable();
                ArrayList _alCRUD = new ArrayList();

                SP.spArgumentsCollection(_alCRUD, "@seachid", Session["warrPrint"].ToString(), "Varchar", "I");
                SP.RunStoredProcedure(dt, "Get_custsalsdetails", _alCRUD);
                if (dt.Rows.Count > 0)
                {
                    Name = dt.Rows[0]["Cname"].ToString();
                    address = dt.Rows[0]["address"].ToString();
                    gstno = dt.Rows[0]["gstno"].ToString();
                    
                }
            }
            catch (Exception ex)
            {

            }
        }
        private void getCompanyDetails()
        {
            try
            {
                string query = "Select * from AdminUser";
                DataTable dt = new DataTable();
                dt = sqldb.getDataTable(query);
                CompanyGstno = dt.Rows[0]["GstNo"].ToString();
                CEmail = dt.Rows[0]["EmailId"].ToString();
                CbankName = dt.Rows[0]["BankName"].ToString();
                cbranch = dt.Rows[0]["Branch"].ToString();
                cAcNo = dt.Rows[0]["Acno"].ToString();
                compaddress = dt.Rows[0]["address"].ToString();
                cifstcode = dt.Rows[0]["IFSCCode"].ToString();
                Term1 = dt.Rows[0]["termC1"].ToString();
                term2 = dt.Rows[0]["termC2"].ToString();
                term3 = dt.Rows[0]["termC3"].ToString();
                term4 = dt.Rows[0]["termC4"].ToString();
                term5 = dt.Rows[0]["termC5"].ToString();
            }
            catch { }
        }
        public void print()
        {
            try
            {
                DataTable dt = new DataTable();
                ArrayList _alCRUD = new ArrayList();

                SP.spArgumentsCollection(_alCRUD, "@serialNo", Session["warrPrint"].ToString(), "Varchar", "I");
                SP.RunStoredProcedure(dt, "GEt_warrantyStatus", _alCRUD);
                if (dt.Rows.Count > 0)
                {
                    grvItem.DataSource = dt;
                    grvItem.DataBind();
                    sqldb.SetGridRowVisible(grvItem, "1,2");
                }
            }
            catch (Exception ex)
            {

            }
        }

    }
}