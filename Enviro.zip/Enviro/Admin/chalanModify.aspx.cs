﻿using CCSBMS.App_code;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CCSBMS.Admin
{
    public partial class chalanModify : System.Web.UI.Page
    {
        db sqldb = new db();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack == true)
                {

                    GetSalesDetails();
                    chalanmodifydiv.Visible = false;
                    editDiv.Visible = false;
                    Session["Q"] = "";
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please Login..., You are automatic redirect at User Login Window.'); window.location.href = '../Default.aspx';", true);
            }
        }
        private void GetItem()
        {
            string query = "select '0' as Id,'-select Item-' as Name union all select  Id,item_name as Name from items";
            DataTable dt = new DataTable();
            dt = sqldb.GetDataTable(query);
            if (dt.Rows.Count > 0)
            {
                DDLItem.DataSource = dt;
                DDLItem.DataTextField = "Name";
                DDLItem.DataValueField = "ID";
                DDLItem.DataBind();

            }
        }
        private void GetSalesDetails()
        {
            try
            {
                DataTable dt = new DataTable();
                ArrayList _alCRUD = new ArrayList();

                SP.spArgumentsCollection(_alCRUD, "@InvoiceNo", Session["Invoice"].ToString(), "Varchar", "I");
                SP.RunStoredProcedure(dt, "Get_ChalanPrintdetails", _alCRUD);
                if (dt.Rows.Count > 0)
                {
                    grvItem.DataSource = dt;
                    grvItem.DataBind();
                }
                grvItem.DataSource = dt;
                grvItem.DataBind();
            }
            catch (Exception ex)
            {

            }
        }
        protected void btnChanalUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "update chalan_s_prodets set serialNo='"+DDlserialNo.SelectedItem.ToString()+"' where serialNo='"+ Session["ESerialNo"].ToString()+ "' and CustomerId='"+ Session["Invoice"].ToString() + "'";                    
                int ret = sqldb.excuteSql(query);
                if(ret>0)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Updated ');", true);
                    GetSalesDetails();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('error btnChanalUpdate_Click');", true);
                }
            }
            catch(Exception ex)
            {
            }
        }
        protected void grvItem_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                int index = 0, ret = 0;

                DataTable dtdlt = new DataTable();
                index = Convert.ToInt32(e.CommandArgument);
                if (e.CommandName == "Delete")
                {
                    Session["ESerialNo"] = grvItem.Rows[index].Cells[4].Text;
                   
                    try
                    {
                        string query = "update chalan_s_prodets set status='D' where serialNo='" + Session["ESerialNo"].ToString() + "' and CustomerId='" + Session["Invoice"].ToString() + "'" +
                            "update item_serialNo set CHSNSTATUS='A' where SerialNo='" + Session["ESerialNo"].ToString() + "'";
                        int ret2 = sqldb.excuteSql(query);
                        if (ret2 > 0)
                        {
                            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Dosdfhsdfhne')", true);
                            //ClientScript.RegisterClientScriptBlock(GetType(), "showalert", "alert('Dosdfhsdfhne')", true /* addScriptTags */);
                            GetSalesDetails();
                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('error grvItem_RowCommand ');", true);
                        }
                    }
                    catch (Exception ex)
                    {
                    }

                   // ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Dosdfhsdfhne')", true);
                }
                if (e.CommandName == "idedit")
                {
                    //editDiv.Visible = true;
                    //chalanmodifydiv.Visible = false;
                    //Session["ESerialNo"] = grvItem.Rows[index].Cells[4].Text;
                    ////txtqty.Text = "1";
                    
                    //txtitemName.Text= grvItem.Rows[index].Cells[12].Text;
                    //txtserailNo.Text = grvItem.Rows[index].Cells[4].Text;
              
                    //GetRemaningSerialNO(grvItem.Rows[index].Cells[5].Text);
                }
            }
            catch (Exception Ex)
            {

            }
        }

        public void GetRemaningSerialNO(string itemid)
        {
            try
            {

                string getSerial = "select SerialNo as Name , ID from item_serialNo where  status='A' and itemid='" + itemid + "' ";
                DataTable dtserali = new DataTable();
                dtserali = sqldb.GetDataTable(getSerial);
                if (dtserali.Rows.Count > 0)
                {
                    DDlserialNo.DataSource = dtserali;
                    DDlserialNo.DataTextField = "Name";
                    DDlserialNo.DataValueField = "ID";
                    DDlserialNo.DataBind();

                }
                dtserali.Clear();
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + ex.Message + "');", true);
            }
        }
        protected void txtqty_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int qty = 1;
                double price = 0.0, sals = 0.0, disc = 0.00, sgst = 0.00, cgst = 0.00, netvalue = 0.00;
                if (txtSalesPrice.Text == "")
                    sals = 0.0;
                else
                {
                    try
                    {
                        sals = Convert.ToDouble(Convert.ToInt32(txtSalesPrice.Text));
                    }
                    catch
                    {
                        sals = Convert.ToDouble(txtSalesPrice.Text);
                    }


                }
                if (txtdisper1.Text == "")
                    disc = 0.0;
                else
                {
                    try
                    {
                        disc = Convert.ToDouble(Convert.ToInt32(txtdisper1.Text));
                    }
                    catch
                    {
                        disc = Convert.ToDouble(txtdisper1.Text);
                    }


                }
                if (txtsgst.Text == "")
                {
                    sgst = 0.0;
                }
                else
                {
                    try
                    {
                        sgst = Convert.ToDouble(Convert.ToInt32(txtsgst.Text));
                    }
                    catch
                    {
                        sgst = Convert.ToDouble(txtsgst.Text);
                    }

                }
                if (txtcgst.Text == "")
                {
                    cgst = 0.0;
                }
                else
                {
                    try
                    {
                        cgst = Convert.ToDouble(Convert.ToInt32(txtcgst.Text));
                    }
                    catch
                    {
                        cgst = Convert.ToDouble(txtcgst.Text);
                    }

                }
                price = qty * sals;
                ViewState["disamount"] = (price) * ((disc) / 100);
                ViewState["gstamount"] = (price - Convert.ToDouble(ViewState["disamount"])) * ((sgst + cgst) / 100);
                price = (price - Convert.ToDouble(ViewState["disamount"])) + Convert.ToDouble(ViewState["gstamount"]);
                netvalue = price;
                ViewState["NetAmt"] = netvalue;
                txtNetValue.Text = netvalue.ToString();
               
            }
            catch (Exception ex)
            {

            }

        }
        protected void DDLItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                string query = "select Id,item_name as Name,taxper,Company,ItemGroup,salePrice,MRP,Purchase,waranty from items where id='" + DDLItem.SelectedValue.ToString() + "'";
                DataTable dt = new DataTable();
                dt = sqldb.GetDataTable(query);
                if (dt.Rows.Count > 0)
                {
                    // ShortName.Text = dt.Rows[0]["shortName"].ToString();
                    //txtMRP.Text = dt.Rows[0]["MRP"].ToString();
                    //Group.Text = dt.Rows[0]["ItemGroup"].ToString();
                    txtSalesPrice.Text = dt.Rows[0]["salePrice"].ToString();

                    //txtWarranty.Text = dt.Rows[0]["waranty"].ToString();
                    txtsgst.Text = (Convert.ToInt32(dt.Rows[0]["taxper"].ToString()) / 2).ToString();
                    txtcgst.Text = (Convert.ToInt32(dt.Rows[0]["taxper"].ToString()) / 2).ToString();
                }
                dt.Clear();
                GetRemaningSerialNO();
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + ex.Message + "');", true);
            }
        }
        protected void Add_Click(object sender, EventArgs e)
        {
            chalanmodifydiv.Visible = true;
            GetItem();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dtitems = new DataTable();
                dtitems.Columns.Add("ItemId", typeof(string));
                dtitems.Columns.Add("Qty", typeof(string));
                dtitems.Columns.Add("salesPrice", typeof(string));
                dtitems.Columns.Add("SerialNo", typeof(string));
                //dtitems.Columns.Add("BasicPrice", typeof(string));
                dtitems.Columns.Add("Dis", typeof(string));
                dtitems.Columns.Add("DisAmount", typeof(double));
                dtitems.Columns.Add("SGST", typeof(string));
                dtitems.Columns.Add("CGST", typeof(string));
                //dtitems.Columns.Add("IGST", typeof(string));
                dtitems.Columns.Add("GstAmount", typeof(double));
                if (GridView1.Rows.Count > 0)
                {
                    foreach (GridViewRow row in GridView1.Rows)
                    {
                        DataRow dr1 = dtitems.NewRow();
                        for (int i = 0; i < row.Cells.Count; i++)
                            dr1[i] = row.Cells[i].Text;
                        dtitems.Rows.Add(dr1);
                    }
                }
                int ret = 0;
                    for (int i = 0; i < dtitems.Rows.Count; i++)
                    {
                        string qu = "insert into chalan_s_prodets" +
                            "(QtyPic," +
                            "salesPrice," +
                            "SerialNo," +

                            "Discper," +
                            "DiscAmt," +
                            "CGST," +
                            "SGST," +
                           
                            "gstamt," +
                            "CustomerId," +
                            "salesDate," +
                            "Item_ID," +
                            "status) " +
                            "values" +
                            "('" + dtitems.Rows[i]["Qty"].ToString() + "'," +
                            "'" + dtitems.Rows[i]["salesPrice"].ToString() + "'," +
                            "'" + dtitems.Rows[i]["SerialNo"].ToString() + "'," +

                            "'" + dtitems.Rows[i]["Dis"].ToString() + "'," +
                            "'" + dtitems.Rows[i]["DisAmount"].ToString() + "'," +
                            "'" + dtitems.Rows[i]["CGST"].ToString() + "'," +
                            "'" + dtitems.Rows[i]["SGST"].ToString() + "'," +
                            
                            "'" + dtitems.Rows[i]["GstAmount"].ToString() + "'," +
                            "'" + Session["Invoice"].ToString() + "'," +
                            "'" + Convert.ToDateTime(txtsalsdate.Text).ToString("yyyy/MM/dd") + "'," +
                            //no erase
                            "'" + dtitems.Rows[i]["ItemId"].ToString() + "'," +
                            "'A') ";
                      ret=  sqldb.excuteSql(qu);

                    }
                    if(ret>0)
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Done');window.location.href = 'ChalanReport.aspx';", true);
                    else
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Somthing Error ');", true);
            }
            catch (Exception ex)
            {
            }
        }
        //private void GetRemaningSerialNOADD()
        //{

        //    Session["Q"] = Session["Q"].ToString() + "and SerialNo <> '" + DropDownList1.SelectedItem.ToString() + "' ";
        //    string getSerial = "select SerialNo as Name , ID from item_serialNo where  status='A' and itemid='" + DDLItem.SelectedValue.ToString() + "'  " + Session["Q"].ToString() + " ";
        //    DataTable dtserali = new DataTable();
        //    dtserali = sqldb.GetDataTable(getSerial);
        //    if (dtserali.Rows.Count >= 0)
        //    {
        //        DropDownList1.DataSource = dtserali;
        //        DropDownList1.DataTextField = "Name";
        //        DropDownList1.DataValueField = "ID";
        //        DropDownList1.DataBind();

        //    }
        //    else
        //    {

        //    }
        //    dtserali.Clear();
        //}

        public void GetRemaningSerialNO()
        {
            try
            {

                string getSerial = "select SerialNo as Name , ID from item_serialNo where  CHSNSTATUS='A' and status='A'  and itemid='" + DDLItem.SelectedValue.ToString() + "' ";
                DataTable dtserali = new DataTable();
                dtserali = sqldb.GetDataTable(getSerial);
                if (dtserali.Rows.Count > 0)
                {
                    DropDownList1.DataSource = dtserali;
                    DropDownList1.DataTextField = "Name";
                    DropDownList1.DataValueField = "ID";
                    DropDownList1.DataBind();

                }
                dtserali.Clear();
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + ex.Message + "');", true);
            }
        }
        protected void Button2Add_Click(object sender, EventArgs e)
        {
            try
            {
                //DataTable s_dt = new DataTable();
                //string query = " select * from item_serialNo where SerialNo = '"+DDlserialNo.SelectedItem.ToString()+"' and status = 'A' and itemid='"+DDLItem.SelectedValue.ToString()+"'";
                //s_dt = sqldb.getDataTable(query);
                //if (s_dt.Rows.Count > 0)
                //{


                DataTable dt = new DataTable();
                dt.Columns.Add("ItemId", typeof(string));
                dt.Columns.Add("Qty", typeof(string));
                dt.Columns.Add("salesPrice", typeof(string));
                dt.Columns.Add("SerialNo", typeof(string));
                //dt.Columns.Add("BasicPrice", typeof(string));
                dt.Columns.Add("Dis%", typeof(string));
                dt.Columns.Add("DisAmount", typeof(double));
                dt.Columns.Add("SGST", typeof(string));
                dt.Columns.Add("CGST", typeof(string));
                //dt.Columns.Add("IGST", typeof(string));
                dt.Columns.Add("GstAmount", typeof(double));

                if (GridView1.Rows.Count > 0)
                {
                    foreach (GridViewRow row in GridView1.Rows)
                    {
                        DataRow dr1 = dt.NewRow();
                        for (int i = 0; i < row.Cells.Count; i++)
                            dr1[i] = row.Cells[i].Text;
                        dt.Rows.Add(dr1);
                    }
                }


                DataRow dr = dt.NewRow();
                dr["ItemId"] = DDLItem.SelectedValue.ToString();
                dr["Qty"] = "1";
                dr["salesPrice"] = txtSalesPrice.Text;
                dr["SerialNo"] = DropDownList1.SelectedItem.ToString();
                //dr["BasicPrice"] = txtqty.Text;
                dr["Dis%"] = txtdisper1.Text;
                dr["DisAmount"] = Convert.ToDouble(ViewState["disamount"]);
                ViewState["TolDisAmt"] = Convert.ToDouble(ViewState["TolDisAmt"]) + Convert.ToDouble(ViewState["disamount"]);

                dr["SGST"] = txtsgst.Text;
                dr["CGST"] = txtcgst.Text;
                //dr["IGST"] = txtigst.Text;
                dr["GstAmount"] = Convert.ToDouble(ViewState["gstamount"]);
                ViewState["TolGstAmt"] = Convert.ToDouble(ViewState["TolGstAmt"]) + Convert.ToDouble(ViewState["gstamount"]);
                ViewState["ToNetAmt"] = Convert.ToDouble(ViewState["ToNetAmt"]) + Convert.ToDouble(ViewState["NetAmt"]);
                LTOTAL.Text = ViewState["ToNetAmt"].ToString();
                Ldis.Text = ViewState["TolDisAmt"].ToString();
                lgst.Text = ViewState["TolGstAmt"].ToString();
                dt.Rows.Add(dr);

                GridView1.DataSource = dt;
                GridView1.DataBind();

                string q = "update item_serialNo set CHSNSTATUS='C' where SerialNo='" + DropDownList1.SelectedItem.ToString() + "'";
                sqldb.excuteSql(q);
                GetRemaningSerialNO();
                //}
                //else
                //{
                //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('This Serial No Does Not Exist')", true);
                //}
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + ex.Message + " No Serial No');", true);
            }
        }

        protected void grvItem_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }
    }
}