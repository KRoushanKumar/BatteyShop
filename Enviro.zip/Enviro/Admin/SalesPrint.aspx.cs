﻿using CCSBMS.App_code;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CCSBMS.Admin
{
    public partial class SalesPrint : System.Web.UI.Page
    {
        db sqldb = new db();
        public string InvoiceNO,discount,Phone, InvoiceDate, Name, Address, GSTIN, State, Pincode, InvoiceAmountinword, Amtbeftax, SGST, CGST, AmountGST, AmtAfterTaX;
        public string CompanyGstno, CEmail,compaddress ,CbankName, cbranch, cAcNo, cifstcode, Term1, term2, term3, term4, term5;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack == true)
                {
                    getCustomerDetails();
                    GetSalesDetails();
                    //  getAmountDetails();
                    getCompanyDetails();

                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please Login..., You are automatic redirect at User Login Window.'); window.location.href = '../Default.aspx';", true);
            }
        }

        private void getCompanyDetails()
        {
            try
            {
                string query = "Select * from AdminUser";
                DataTable dt = new DataTable();
                dt = sqldb.getDataTable(query);
                CompanyGstno = dt.Rows[0]["GstNo"].ToString();
                CEmail = dt.Rows[0]["EmailId"].ToString();
                CbankName = dt.Rows[0]["BankName"].ToString();
                cbranch = dt.Rows[0]["Branch"].ToString();
                cAcNo = dt.Rows[0]["Acno"].ToString();
                compaddress = dt.Rows[0]["address"].ToString();
                cifstcode = dt.Rows[0]["IFSCCode"].ToString();
                Term1 = dt.Rows[0]["termC1"].ToString();
                term2 = dt.Rows[0]["termC2"].ToString();
                term3 = dt.Rows[0]["termC3"].ToString();
                term4 = dt.Rows[0]["termC4"].ToString();
                term5 = dt.Rows[0]["termC5"].ToString();
            }
            catch { }
        }

        private void getAmountDetails()
        {
            
        }

        private void getCustomerDetails()
        {
            try
            {
                DataTable dt = new DataTable();
                ArrayList _alCRUD = new ArrayList();

                SP.spArgumentsCollection(_alCRUD, "@InvoiceNo", Session["Invoice"].ToString(), "Varchar", "I");
                SP.RunStoredProcedure(dt, "Get_PaticualCustomersalesdetails", _alCRUD);
                if (dt.Rows.Count > 0)
                {

                    InvoiceNO = Session["Invoice"].ToString();
                    InvoiceDate = dt.Rows[0]["Sales Date"].ToString();
                    Name = dt.Rows[0]["CName"].ToString();                 
                    GSTIN = dt.Rows[0]["GstNo"].ToString();
                    State = dt.Rows[0]["state"].ToString();
                    Pincode = dt.Rows[0]["pincode"].ToString();
                    Address = dt.Rows[0]["address"].ToString();
                    discount= dt.Rows[0]["Discount Amount"].ToString();
                    AmountGST = dt.Rows[0]["GST Amount"].ToString();
                    AmtAfterTaX = dt.Rows[0]["Amount"].ToString();
                    Phone=dt.Rows[0]["Mob"].ToString();
                    InvoiceAmountinword = sqldb.ConvertNumbertoWords(Convert.ToInt32(AmtAfterTaX));
                }




            }
            catch { }
        }

        private void GetSalesDetails()
        {
            try
            {
                DataTable dt = new DataTable();
                ArrayList _alCRUD = new ArrayList();

                SP.spArgumentsCollection(_alCRUD, "@InvoiceNo", Session["Invoice"].ToString(), "Varchar", "I");
                SP.RunStoredProcedure(dt, "Get_salesPrintdetails", _alCRUD);
                if (dt.Rows.Count > 0)
                {
                    
                    grvItem.DataSource = dt;
                    grvItem.DataBind();

                }




            }
            catch (Exception ex)
            {

            }
        }
        
    }
}