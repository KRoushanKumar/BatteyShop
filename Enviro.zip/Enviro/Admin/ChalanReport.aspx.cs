﻿using CCSBMS.App_code;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CCSBMS.Admin
{
    public partial class ChalanReport : System.Web.UI.Page
    {
        db sqldb = new db();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ID"] != null)
            {
                if (!IsPostBack == true)
                {

                    GetSalesDetails();

                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Please Login..., You are automatic redirect at User Login Window.'); window.location.href = '../Default.aspx';", true);
            }
        }

        private void GetSalesDetails()
        {
            try
            {
                DataTable dt = new DataTable();
                ArrayList _alCRUD = new ArrayList();

                SP.spArgumentsCollection(_alCRUD, "@InvoiceNo", txtinvoiceNo.Text, "Varchar", "I");
                SP.RunStoredProcedure(dt, "Get_chalandetails", _alCRUD);
                if (dt.Rows.Count > 0)
                {
                    grvItem23.DataSource = dt;
                    grvItem23.DataBind();
                    sqldb.SetGridRowVisible(grvItem23, "9,10,11");
                }
            }
            catch (Exception ex)
            {

            }
        }

        protected void grvItem_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                int index = 0, ret = 0;

                DataTable dtdlt = new DataTable();
                index = Convert.ToInt32(e.CommandArgument);
                if (e.CommandName == "cniprint")
                {
                    Session["Invoice"] = grvItem23.Rows[index].Cells[5].Text;

                    Response.Redirect("ChanalPrintOrEdit.aspx");


                }
                if (e.CommandName == "idedit")
                {
                    Session["Invoice"] = grvItem23.Rows[index].Cells[5].Text;

                    Response.Redirect("chalanModify.aspx");


                }
            }
            catch (Exception Ex)
            {

            }
        }

        protected void BTNNEW_Click(object sender, EventArgs e)
        {

        }

        protected void SearchChalan_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch(Exception ex)
            {

            }
        }

        protected void grvItem_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void grvItem_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {

        }
    }
}