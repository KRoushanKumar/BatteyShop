﻿using System;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Drawing.Printing;
using System.Collections;

using System.Text;
using System.Net.Mail;
using System.Net;
using System.Text.RegularExpressions;
namespace CCSBMS.App_code
{
    public class db
    {
        //String path = HttpContext.Current.Request.PhysicalApplicationPath + "Uploded_Images\\";


        public SqlConnection Sqlconn;
        public SqlCommand SqlCmd = new SqlCommand();

        public db()
        {
            Sqlconn = new SqlConnection(ConfigurationManager.ConnectionStrings["bms"].ToString());

        }
        public void OpenConnection()
        {
            try
            {
                Sqlconn.Open();
                SqlCmd.Connection = Sqlconn;
            }
            catch (Exception ex)
            {


            }
        }

        public void CloseConnection()
        {
            try
            {
                Sqlconn.Close();
            }
            catch (Exception ex)
            {


            }
        }

        public int excuteSql(string strSql)
        {
            int rtn = 0;

            try
            {

                SqlCmd.Connection = Sqlconn;
                SqlCmd.Connection.Open();
                SqlCmd.CommandType = CommandType.Text;
                SqlCmd.CommandText = strSql;
                rtn = SqlCmd.ExecuteNonQuery();
                SqlCmd.Connection.Close();

            }
            catch
            {
                SqlCmd.Connection.Close();


            }
            finally
            {
                SqlCmd.Connection.Close();
            }

            return rtn;
        }


        public DataTable GetDataTable(string strSql)
        {
            try
            {
                OpenConnection();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter();
                SqlCmd.CommandType = CommandType.Text;
                SqlCmd.CommandText = strSql;
                SqlCmd.Connection = Sqlconn;
                da.SelectCommand = SqlCmd;
                da.Fill(dt);
                CloseConnection();
                return dt;
            }
            catch (Exception ex)
            {

                return null;
            }

        }

        public DataSet GetDataSet(string strSql)
        {
            try
            {
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter();
                SqlCmd.CommandType = CommandType.Text;
                SqlCmd.CommandText = strSql;
                SqlCmd.Connection = Sqlconn;
                da.SelectCommand = SqlCmd;
                da.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {

                return null;
            }


        }

        //public string fileDelete(string str, int iStr)
        //{
        //    System.IO.File.Delete(path + iStr.ToString() + "_" + str);


        //    return str;
        //}   
        public void GetData(string str, DropDownList ddl)
        {
            try
            {
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(str, Sqlconn);
                da.Fill(ds, "tbl");
                ddl.DataSource = ds;
                ddl.DataTextField = "Name";
                ddl.DataValueField = "ID";
                ddl.DataBind();
            }
            catch (Exception ex)
            {


            }
        }

        public DataTable getDataTable(string strSql)
        {

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter();
            SqlCmd.CommandType = CommandType.Text;
            SqlCmd.CommandText = strSql;
            SqlCmd.Connection = Sqlconn;
            da.SelectCommand = SqlCmd;
            da.Fill(dt);
            return dt;

        }
        public String GetImageFromBytes(object obj)
        {
            try
            {
                string img = "data:image/gif;base64,{0}"; //change image type if need be
                byte[] toEncodeAsBytes = (byte[])obj;
                string returnValue = System.Convert.ToBase64String(toEncodeAsBytes);
                return String.Format(img, returnValue);
            }
            catch
            {
                return "";
            }
        }
        public int LoaduserRightsCheck(int mid, int userid)
        {
            int retvalue = 0, userType = 0;
            try
            {
                db clsuser = new db();
                string path = HttpContext.Current.Request.Url.AbsoluteUri;
                string FPathName = Path.GetFileName(path).ToString();

                DataTable dtuser = new DataTable();
                string struser;
                struser = "select USerType from webUser where id = " + userid;
                dtuser = clsuser.GetDataTable(struser);
                if (dtuser.Rows.Count > 0)
                {
                    userType = Convert.ToInt32(dtuser.Rows[0]["UserType"].ToString());
                }
                if (userType == 1)
                {
                    retvalue = 2;
                }
                else
                {
                    struser = "select * from m_MENU mn inner join m_rights mrg  on mrg.r_codeID = mn.m_id where mn.m_id = '" + mid + " ' and mrg.r_userID = " + userid;
                    dtuser = clsuser.GetDataTable(struser);

                    if (dtuser.Rows.Count > 0)
                    {
                        retvalue = 2;//Response.Redirect(PageNameD);
                    }
                    else
                    {
                        retvalue = 1;//Response.Redirect("PermisionError.aspx");
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return retvalue;
        }
        public int LoadUnivRightsCheck(int id, int clgid)
        {
            int retvalue = 0;
            try
            {
                db clsuser = new db();
                string path = HttpContext.Current.Request.Url.AbsoluteUri;
                string FPathName = Path.GetFileName(path).ToString();

                DataTable dtuser = new DataTable();
                string struser;

                struser = "select * from m_Userrights mrg where mrg.r_userID=" + id + " and mrg.college_id=" + clgid;
                dtuser = clsuser.GetDataTable(struser);
                if (dtuser.Rows.Count > 0)
                {
                    //Response.Redirect(PageNameD);
                    retvalue = 1;

                }
                else
                {
                    //Response.Redirect("PermisionError.aspx");
                    retvalue = 0;

                }

            }
            catch (Exception ex)
            {

            }
            return retvalue;
        }

        public byte[] ConvertImageToByteArray(System.Drawing.Image imageToConvert, System.Drawing.Imaging.ImageFormat formatOfImage)
        {
            byte[] Ret;
            try
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    imageToConvert.Save(ms, formatOfImage);
                    Ret = ms.ToArray();
                }
            }
            catch (Exception) { throw; }
            return Ret;
        }
        public int LoadCollegeRights(int id, Page page)
        {
            int retvalue = 0;
            try
            {
                db clsuser = new db();
                string path = HttpContext.Current.Request.Url.AbsoluteUri;
                string FPathName = Path.GetFileName(path).ToString();

                DataTable dtuser = new DataTable();
                string struser;

                struser = "select * from Colleges C inner join m_Userrights Ur on Ur.college_id=C.ID where Ur.College_id=" + id;
                dtuser = clsuser.GetDataTable(struser);
                if (dtuser.Rows.Count > 0)
                {
                    //Response.Redirect(PageNameD);
                    retvalue = 1;

                }
                else
                {
                    //Response.Redirect("PermisionError.aspx");
                    retvalue = 0;

                }

            }
            catch (Exception ex)
            {

            }
            return retvalue;
        }
        /* Convert from amount to word */
        public string ConvertNumbertoWords(int number)
        {
            if (number == 0)
                return "ZERO";
            if (number < 0)
                return "minus " + ConvertNumbertoWords(Math.Abs(number));
            string words = "";
            if ((number / 1000000) > 0)
            {
                words += ConvertNumbertoWords(number / 1000000) + " MILLION ";
                number %= 1000000;
            }
            if ((number / 1000) > 0)
            {
                words += ConvertNumbertoWords(number / 1000) + " THOUSAND ";
                number %= 1000;
            }
            if ((number / 100) > 0)
            {
                words += ConvertNumbertoWords(number / 100) + " HUNDRED ";
                number %= 100;
            }
            if (number > 0)
            {
                if (words != "")
                    words += "AND ";
                var unitsMap = new[] { "ZERO", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN", "ELEVEN", "TWELVE", "THIRTEEN", "FOURTEEN", "FIFTEEN", "SIXTEEN", "SEVENTEEN", "EIGHTEEN", "NINETEEN" };
                var tensMap = new[] { "ZERO", "TEN", "TWENTY", "THIRTY", "FORTY", "FIFTY", "SIXTY", "SEVENTY", "EIGHTY", "NINETY" };

                if (number < 20)
                    words += unitsMap[number];
                else
                {
                    words += tensMap[number / 10];
                    if ((number % 10) > 0)
                        words += " " + unitsMap[number % 10];
                }
            }
            return words;
        }
        public void SetGridRowVisible(GridView rgv, String idxs)
        {
            int i;
            String[] idxarr = idxs.Split(',');
            int index = 0;
            try
            {
                foreach (String idx in idxarr)
                {
                    index = Convert.ToInt32(idx);
                    rgv.HeaderRow.Cells[index].Visible = false;
                    for (i = 0; i < rgv.Rows.Count; i++)
                    {
                        rgv.Rows[i].Cells[index].Visible = false;
                    }
                }
            }
            catch { }
        }


        public void SetGridFooterRowVisible(GridView rgv, String idxs)
        {
            int i;
            String[] idxarr = idxs.Split(',');
            int index = 0;
            try
            {
                foreach (String idx in idxarr)
                {
                    index = Convert.ToInt32(idx);
                    rgv.FooterRow.Cells[index].Visible = false;
                    for (i = 0; i < rgv.Rows.Count; i++)
                    {
                        rgv.Rows[i].Cells[index].Visible = false;
                    }
                }
            }
            catch { }
        }
        public void SetError(string desc, string pagename)
        {
            Int32 RetValue = 0, ret;
            try
            {
                string path = HttpContext.Current.Request.Url.AbsoluteUri;
                string FPathName = Path.GetFileName(path).ToString();
                ArrayList arLst = new ArrayList();
                SP.spArgumentsCollection(arLst, "@Ex_Desc", desc, "varchar", "I");
                SP.spArgumentsCollection(arLst, "@Ex_source", pagename, "varchar", "I");
                SP.spArgumentsCollection(arLst, "@From_Statement", FPathName, "varchar", "I");
                RetValue = SP.RunStoredProcedureWithReturn("sp_insertException", arLst);
                if (RetValue == 1)
                {
                    ret = 1;
                }
                else
                {
                    ret = -1;
                }
            }
            catch (Exception ex)
            {
                ret = -404;
            }
            //return ret;

        }

        public Int32 getmenurights(string as_menuId, string ac_RightType, Int32 UID)
        {
            Int32 right = 0;
            db db_access = new db();
            //string str_getpageName = string.Empty;
            //DataTable dt_getmName = new DataTable();

            try
            {
                //str_getpageName = "select count(m_id)   From m_menu where Upper(m_text) ='" + as_menuname.Trim().ToUpper() + "'";
                //dt_getmName = db_access.getDataTable(str_getpageName);

                //if (dt_getmName.Rows.Count > 0)
                if (as_menuId != "" || as_menuId != null)
                {
                    string str_getRights = string.Empty;
                    DataTable dt_getVal = new DataTable();
                    switch (ac_RightType)
                    {
                        case "R":
                            str_getRights = "select isnull(r_read,0) as Val ";
                            str_getRights += " from m_rights ";
                            str_getRights += " where r_userID =   " + UID;
                            str_getRights += " AND  Isnull(Menu_Id,R_CodeId) = " + Convert.ToInt32(as_menuId);
                            //str_getRights += " AND  Menu_Id = (select top 1 m_id  ";
                            //str_getRights += " From m_menu ";
                            //str_getRights += " where Upper(m_text) = '" + as_menuname.Trim().ToUpper() + "' and m_visible=1) ";
                            str_getRights += " and r_code = 'M' ";

                            dt_getVal = db_access.getDataTable(str_getRights);
                            if (dt_getVal.Rows.Count > 0)
                            {
                                right = Convert.ToInt32(dt_getVal.Rows[0]["Val"].ToString());
                            }
                            else
                            {
                                right = -1;
                            }

                            break;
                        case "W":
                            str_getRights = "select isnull(r_Write,0) as Val ";
                            str_getRights += " from m_rights ";
                            str_getRights += " where r_userID =" + UID;
                            str_getRights += " AND  Isnull(Menu_Id,R_CodeId) = " + Convert.ToInt32(as_menuId);
                            //str_getRights += " AND  Menu_Id = (select top 1 m_id  ";
                            //str_getRights += " From m_menu ";
                            //str_getRights += " where Upper(m_text) = '" + as_menuname.Trim().ToUpper() + "' and m_visible=1) ";
                            str_getRights += " and r_code = 'M' ";

                            dt_getVal = db_access.getDataTable(str_getRights);
                            if (dt_getVal.Rows.Count > 0)
                            {
                                right = Convert.ToInt32(dt_getVal.Rows[0]["Val"].ToString());
                            }
                            else
                            {
                                right = -1;
                            }
                            break;
                        case "X":
                            str_getRights = "select isnull(r_Execute,0) as Val ";
                            str_getRights += " from m_rights ";
                            str_getRights += " where r_userID  =" + UID;
                            str_getRights += " AND  Isnull(R_CodeId,0) = " + Convert.ToInt32(as_menuId);
                            //str_getRights += " AND  Menu_Id = (select top 1 m_id  ";
                            //str_getRights += " From m_menu ";
                            //str_getRights += " where Upper(m_text) = '" + as_menuname.Trim().ToUpper() + "' and m_visible=1) ";
                            str_getRights += " and r_code = 'M' ";

                            dt_getVal = db_access.getDataTable(str_getRights);
                            if (dt_getVal.Rows.Count > 0)
                            {
                                right = Convert.ToInt32(dt_getVal.Rows[0]["Val"].ToString());
                            }
                            else
                            {
                                right = -1;
                            }
                            break;

                        default:
                            right = 0;
                            break;
                    }
                }
                else
                {
                    right = -1;
                }

            }
            catch (Exception ex)
            {
                db_access.SetError(ex.Message, "App_Code/db.cs/getmenurights()");
            }


            return right;
        }

        public int findRights(string PageId, int UID)
        {
            int ret = 0;
            //int read = 0, write = 0;
            int execute = 0;
            db cls = new db();
            try
            {
                //string menu = "select m_text from m_menu Where m_id =" + Pagename ;
                //DataTable menudt = new DataTable();
                //menudt = cls.getDataTable(menu);

                // read = cls.getmenurights(menudt.Rows[0].ItemArray[0].ToString(), "R", Convert.ToInt32(UID));
                // write = cls.getmenurights(menudt.Rows[0].ItemArray[0].ToString(), "W", Convert.ToInt32(UID));
                //execute = cls.getmenurights(menudt.Rows[0].ItemArray[0].ToString(), "X", Convert.ToInt32(UID));

                execute = cls.getmenurights(PageId, "X", Convert.ToInt32(UID));

                ret = execute;

            }
            catch (Exception ex)
            {
                ret = -1;
            }
            return ret;
        }



        public string ToRoman(int number)
        {
            if ((number < 0) || (number > 3999)) throw new ArgumentOutOfRangeException("insert value betwheen 1 and 3999");
            if (number < 1) return string.Empty;
            if (number >= 1000) return "M" + ToRoman(number - 1000);
            if (number >= 900) return "CM" + ToRoman(number - 900); //EDIT: i've typed 400 instead 900
            if (number >= 500) return "D" + ToRoman(number - 500);
            if (number >= 400) return "CD" + ToRoman(number - 400);
            if (number >= 100) return "C" + ToRoman(number - 100);
            if (number >= 90) return "XC" + ToRoman(number - 90);
            if (number >= 50) return "L" + ToRoman(number - 50);
            if (number >= 40) return "XL" + ToRoman(number - 40);
            if (number >= 10) return "X" + ToRoman(number - 10);
            if (number >= 9) return "IX" + ToRoman(number - 9);
            if (number >= 5) return "V" + ToRoman(number - 5);
            if (number >= 4) return "IV" + ToRoman(number - 4);
            if (number >= 1) return "I" + ToRoman(number - 1);
            throw new ArgumentOutOfRangeException("something bad happened");
        }
        public void bindGrid(GridView gv, DataTable dt)
        {
            gv.DataSource = dt;
            gv.DataBind();
            SetGridAlignment(gv);

        }
        public void SetGridAlignment(GridView gv)
        {

            if (gv.Rows.Count > 0)
                gv.HeaderRow.HorizontalAlign = HorizontalAlign.Left;
            foreach (GridViewRow gvr in gv.Rows)
            {
                if (gvr.RowType == DataControlRowType.Header) continue;
                // gvr.HorizontalAlign = HorizontalAlign.Left;
                foreach (DataControlFieldCell cell in gvr.Cells)
                {
                    string colVal = cell.Text;
                    int Num;
                    decimal dec;
                    try
                    {

                        bool isNum = int.TryParse(colVal, out Num);
                        bool isDec = decimal.TryParse(colVal, out dec);
                        if ((isNum) || (isDec))
                        {
                            cell.HorizontalAlign = HorizontalAlign.Right;
                        }
                    }
                    catch
                    {
                    }
                }
            }
        }

        public string Getsysparm(string keyName)
        {
            db clsparm = new db();
            string keyValue = string.Empty;
            DataTable dtsysparm = new DataTable();
            string struser;
            struser = "select key_Value from SysParameter where upper(key_Name) = '" + keyName.ToUpper() + "'";
            dtsysparm = clsparm.GetDataTable(struser);

            if (dtsysparm.Rows.Count > 0 || dtsysparm == null)
            {
                keyValue = dtsysparm.Rows[0]["key_Value"].ToString();
            }
            else
            {
                string str_sql = string.Empty;
                str_sql = "Insert into sysparameter (key_Name,key_Value,status,unitid,orgid) Values (@keyName,@keyValue,@status,@unitid,@orgid)";
                SqlCommand cmd = new SqlCommand(str_sql, Sqlconn);
                cmd.Parameters.AddWithValue("@keyName", keyName);
                cmd.Parameters.AddWithValue("@keyValue", " ");
                cmd.Parameters.AddWithValue("@status", 'A');
                cmd.Parameters.AddWithValue("@unitid", "1");
                cmd.Parameters.AddWithValue("@orgid", "1");
                Sqlconn.Open();
                cmd.ExecuteNonQuery();
                Sqlconn.Close();
            }
            return keyValue;

        }
        public void setSessionExpire(Page page)
        {
            string script = "<script language='JavaScript'>window.top.location.href='../../Sessionexpire.aspx'; </script>";
            ScriptManager.RegisterStartupScript(page, page.GetType(), "PopupScript", script, false);
        }


        public void PrintWebControl(Control ctrl, string Script)
        {
            try
            {
                StringWriter stringWrite = new StringWriter();
                System.Web.UI.HtmlTextWriter htmlWrite = new System.Web.UI.HtmlTextWriter(stringWrite);
                if (ctrl is WebControl)
                {
                    Unit w = new Unit(100, UnitType.Percentage); ((WebControl)ctrl).Width = w;
                }
                Page pg = new Page();

                pg.EnableEventValidation = false;
                if (Script != string.Empty)
                {
                    pg.ClientScript.RegisterStartupScript(pg.GetType(), "PrintJavaScript", Script);
                }
                HtmlForm frm = new HtmlForm();

                pg.Controls.Add(frm);
                frm.Attributes.Add("runat", "server");

                frm.Controls.Add(ctrl);
                pg.DesignerInitialize();
                pg.RenderControl(htmlWrite);
                string strHTML = stringWrite.ToString();

                HttpContext.Current.Response.Clear();
                HttpContext.Current.Response.Write(strHTML);
                HttpContext.Current.Response.Write("<script>window.print();window.close();</script>");
                HttpContext.Current.Response.End();
            }
            catch (Exception Ex)
            {
                SetError(Ex.Message, "While Printing");
            }

        }
        public void PrintWebControl(Control ctrl, string Script, String _title)
        {
            try
            {
                StringWriter stringWrite = new StringWriter();
                System.Web.UI.HtmlTextWriter htmlWrite = new System.Web.UI.HtmlTextWriter(stringWrite);
                if (ctrl is WebControl)
                {
                    Unit w = new Unit(100, UnitType.Percentage); ((WebControl)ctrl).Width = w;
                }
                Page pg = new Page();

                pg.EnableEventValidation = false;
                if (Script != string.Empty)
                {
                    pg.ClientScript.RegisterStartupScript(pg.GetType(), "PrintJavaScript", Script);
                }
                HtmlForm frm = new HtmlForm();

                pg.Controls.Add(frm);
                frm.Attributes.Add("runat", "server");

                frm.Controls.Add(ctrl);
                pg.DesignerInitialize();
                pg.RenderControl(htmlWrite);
                string strHTML = stringWrite.ToString();
                strHTML = "<html> <head> <title> " + _title + " </title> <script> window.print(); window.close();</script> </head> <body>" + strHTML + "</body> </html>";

                HttpContext.Current.Response.Clear();
                HttpContext.Current.Response.Write(strHTML);

            }
            catch (Exception Ex)
            {
                SetError(Ex.Message, "PrintWebControl : Rendering of Printing failed.");
            }
            finally
            {
                HttpContext.Current.Response.Flush();
                HttpContext.Current.Response.SuppressContent = true;
                HttpContext.Current.ApplicationInstance.CompleteRequest();
            }

        }
        public void setPermissionerror(Page page)
        {
            string script = "<script language='JavaScript'>window.location.href='../../Process/PermisionError.aspx'; </script>";
            ScriptManager.RegisterStartupScript(page, page.GetType(), "PopupScript", script, false);
        }

        public void SendSMS(string AId, string mob, string msg)
        {
            db dbconn = new db();
            string SMSType = string.Empty, RECID = string.Empty, RECTYPE = string.Empty, errorMSG = string.Empty, TranNo = string.Empty;

            //Your authentication key
            string authKey = "240003AM4fhoUJ15bae1389"; // 2099AaXqIB4M57595796";
            //Multiple mobiles numbers separated by comma
            string mobileNumber = mob; //"9693910675";
                                       //Sender ID,While using route4 sender id should be 6 characters long.
            string senderId = "MSGIND";
            //Your message to send, Add URL encoding here.
            //string message = HttpUtility.UrlEncode("Dear <name>, your Application has been Accepted.Please login at www.jdwomenscollege.in using userid <ackno> and password <ackno>");
            string message = HttpUtility.UrlEncode(msg);
            //Prepare you post parameters
            StringBuilder sbPostData = new StringBuilder();
            sbPostData.AppendFormat("authkey={0}", authKey);
            sbPostData.AppendFormat("&mobiles={0}", mobileNumber);
            sbPostData.AppendFormat("&message={0}", message);
            sbPostData.AppendFormat("&sender={0}", senderId);
            sbPostData.AppendFormat("&route={0}", "4");

            try
            {
                //Call Send SMS API
                string sendSMSUri = "https://control.msg91.com/api/sendhttp.php?";
                //Create HTTPWebrequest
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(sendSMSUri);
                //Prepare and Add URL Encoded data
                UTF8Encoding encoding = new UTF8Encoding();
                byte[] data = encoding.GetBytes(sbPostData.ToString());
                //Specify post method
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = data.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                //Get the response
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string responseString = reader.ReadToEnd();

                RECID = "1";
                SMSType = response.ResponseUri.HostNameType.ToString();
                RECTYPE = response.StatusCode.ToString();
                TranNo = responseString;

                if (RECTYPE == "Ok")
                {
                    RECTYPE = "S";
                }
                else
                {
                    RECTYPE = "F";
                }

                SMSType = "T";
                saveSendSMS(AId, mobileNumber, SMSType, message, RECID, RECTYPE, errorMSG, TranNo, RECTYPE);


                //Close the response
                reader.Close();
                response.Close();
            }
            catch (SystemException ex)
            {
                dbconn.SetError(ex.ToString(), "App_Code/ClsDatabase" + "SendSMS()");
            }
        }

        public void saveSendSMS(string SmsProfileId, string SmsTo, string SMSType, string Message, string RECID, string RECTYPE, string errorMSG, string TranNo, string SMSstatus)
        {
            db dbconn = new db();
            string msg = string.Empty;
            try
            {
                ArrayList arlst = new ArrayList();
                int count = 0;
                SP.spArgumentsCollection(arlst, "@Ret", "0", "Int", "O");
                SP.spArgumentsCollection(arlst, "@SmsProfileId", SmsProfileId, "Int", "I");
                SP.spArgumentsCollection(arlst, "@SmsTo", SmsTo, "varchar", "I");
                SP.spArgumentsCollection(arlst, "@SMSType", SMSType, "varchar", "I");
                SP.spArgumentsCollection(arlst, "@Message", Message, "varchar", "I");
                SP.spArgumentsCollection(arlst, "@RECID", RECID, "varchar", "I");
                SP.spArgumentsCollection(arlst, "@RECTYPE", RECTYPE, "varchar", "I");
                SP.spArgumentsCollection(arlst, "@TranData", TranNo, "varchar", "I");
                count = SP.RunStoredProcedureWithReturn("Sp_setSendSMS", arlst);
            }
            catch (Exception ex)
            {
                dbconn.SetError(ex.ToString(), "App_Code/ClsDatabase" + "saveSendSMS()");
            }
        }
        public bool Sendemail(String ToEmail, String subject, string Message, ArrayList emailAtt)
        {

            string user = "ccssaumya1604@gmail.com";//ConfigurationManager.AppSettings["email_username"].ToString();
            string password = "CCS_1996";//ConfigurationManager.AppSettings["email_password"].ToString();
            SmtpClient SmtpServer = new SmtpClient();
            SmtpServer.Credentials = new System.Net.NetworkCredential(user, password);
            SmtpServer.Port = 25;
            //SmtpServer.Port = 587;
            //SmtpServer.Host = "mail.codecaresolution.in";
            SmtpServer.Host = "smtp.gmail.com";
            SmtpServer.EnableSsl = true;
            //SmtpServer.EnableSsl = false;

            MailMessage mail = new MailMessage();
            try
            {
                mail.From = new MailAddress(user, subject, System.Text.Encoding.UTF8);
                mail.To.Add(new MailAddress(ToEmail));
                mail.Subject = subject;
                mail.Body = Message;
                mail.IsBodyHtml = true;
                for (int i = 0; i < emailAtt.Count; i++)
                {
                    mail.Attachments.Add(new Attachment(emailAtt[i].ToString()));
                }

                mail.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
                mail.ReplyTo = new MailAddress("info@codecaresolution.com");
                SmtpServer.Send(mail);

            }
            catch (Exception err)
            {
                return false;
            }
            return true;
        }
        public bool sendConfirmation(string email, string msg)
        {
            string to = string.Empty; //To address 
            to = email;
            string from = "admissionpup@gmail.com"; //From address    
            MailMessage message = new MailMessage(from, to);

            string mailbody = msg;// "We have Recieved Your Query and will shortly perform action on it.\nThank You.";
            message.Subject = "ADMISSION PURNEA UNIVERSITY, PURNEA";
            message.Body = mailbody;
            message.BodyEncoding = Encoding.UTF8;
            message.IsBodyHtml = true;
            SmtpClient client = new SmtpClient("smtp.gmail.com", 587); //Gmail smtp    
            System.Net.NetworkCredential basicCredential1 = new
            System.Net.NetworkCredential("admissionpup@gmail.com", "puadmission@5689");
            client.EnableSsl = true;
            client.UseDefaultCredentials = false;
            client.Credentials = basicCredential1;
            try
            {
                client.Send(message);
                return true;
            }

            catch (Exception ex)
            {
                return false;
            }
        }

        public bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }


        public string DecryptString(string encrString)
        {
            byte[] b;
            string decrypted;
            try
            {
                b = Convert.FromBase64String(encrString);
                decrypted = System.Text.ASCIIEncoding.ASCII.GetString(b);
            }
            catch (FormatException fe)
            {
                decrypted = "";
            }
            return decrypted;
        }

        public string EnryptString(string strEncrypted)
        {
            byte[] b = System.Text.ASCIIEncoding.ASCII.GetBytes(strEncrypted);
            string encrypted = Convert.ToBase64String(b);
            return encrypted;
        }

        public string emailFormate(string name, string userName, string email)
        {
            string strEmail = string.Empty;
            db dbconn = new db();
            try
            {
                strEmail += " <!doctype html> ";
                strEmail += " <html> ";
                strEmail += " <head> ";
                strEmail += " <meta name='viewport' content='width=device-width' /> ";
                strEmail += " <meta http-equiv='Content-Type' content='text/html; charset=UTF-8' /> ";
                strEmail += " <title>Congratulation</title> ";
                strEmail += " <style> ";
                strEmail += " img { ";
                strEmail += " border: none; ";
                strEmail += " -ms-interpolation-mode: bicubic; ";
                strEmail += " max-width: 100%; ";
                strEmail += " } ";

                strEmail += " body { ";
                strEmail += " background-color: #f6f6f6; ";
                strEmail += " font-family: sans-serif; ";
                strEmail += " -webkit-font-smoothing: antialiased; ";
                strEmail += " font-size: 14px; ";
                strEmail += " line-height: 1.4; ";
                strEmail += " margin: 0; ";
                strEmail += " padding: 0; ";
                strEmail += " -ms-text-size-adjust: 100%; ";
                strEmail += " -webkit-text-size-adjust: 100%; ";
                strEmail += " } ";

                strEmail += " table { ";
                strEmail += " border-collapse: separate; ";
                strEmail += " mso-table-lspace: 0pt; ";
                strEmail += " mso-table-rspace: 0pt; ";
                strEmail += " width: 100%; ";
                strEmail += " } ";

                strEmail += " table td { ";
                strEmail += " font-family: sans-serif; ";
                strEmail += " font-size: 14px; ";
                strEmail += " vertical-align: top; ";
                strEmail += " } ";
                strEmail += " .body { ";
                strEmail += " background-color: #f6f6f6; ";
                strEmail += " width: 100%; ";
                strEmail += " } ";
                strEmail += " .container { ";
                strEmail += " display: block; ";
                strEmail += " Margin: 0 auto !important; ";
                strEmail += " /* makes it centered */ ";
                strEmail += " max-width: 580px; ";
                strEmail += " padding: 10px; ";
                strEmail += " width: 580px; ";
                strEmail += " } ";
                strEmail += " .content { ";
                strEmail += " box-sizing: border-box; ";
                strEmail += " display: block; ";
                strEmail += " Margin: 0 auto; ";
                strEmail += " max-width: 580px; ";
                strEmail += " padding: 10px; ";
                strEmail += " } ";
                strEmail += " .main { ";
                strEmail += " background: #ffffff; ";
                strEmail += " border-radius: 3px; ";
                strEmail += " width: 100%; ";
                strEmail += " } ";

                strEmail += " .wrapper { ";
                strEmail += " box-sizing: border-box; ";
                strEmail += " padding: 20px; ";
                strEmail += " } ";

                strEmail += " .content-block { ";
                strEmail += " padding-bottom: 10px; ";
                strEmail += " padding-top: 10px; ";
                strEmail += " } ";

                strEmail += " .footer { ";
                strEmail += " clear: both; ";
                strEmail += " Margin-top: 10px; ";
                strEmail += " text-align: center; ";
                strEmail += " width: 100%; ";
                strEmail += " } ";

                strEmail += " .footer td, ";
                strEmail += " .footer p, ";
                strEmail += " .footer span, ";
                strEmail += " .footer a { ";
                strEmail += " color: #999999; ";
                strEmail += " font-size: 12px; ";
                strEmail += " text-align: center; ";
                strEmail += " } ";
                strEmail += " h1, ";
                strEmail += " h2, ";
                strEmail += " h3, ";
                strEmail += " h4 { ";
                strEmail += " color: #000000; ";
                strEmail += " font-family: sans-serif; ";
                strEmail += " font-weight: 400; ";
                strEmail += " line-height: 1.4; ";
                strEmail += " margin: 0; ";
                strEmail += " Margin-bottom: 30px; ";
                strEmail += " } ";

                strEmail += " h1 { ";
                strEmail += " font-size: 35px; ";
                strEmail += " font-weight: 300; ";
                strEmail += " text-align: center; ";
                strEmail += " text-transform: capitalize; ";
                strEmail += " } ";

                strEmail += " p, ";
                strEmail += " ul, ";
                strEmail += " ol { ";
                strEmail += " font-family: sans-serif; ";
                strEmail += " font-size: 14px; ";
                strEmail += " font-weight: normal; ";
                strEmail += " margin: 0; ";
                strEmail += " Margin-bottom: 15px; ";
                strEmail += " } ";

                strEmail += " p li, ";
                strEmail += " ul li, ";
                strEmail += " ol li { ";
                strEmail += " list-style-position: inside; ";
                strEmail += " margin-left: 5px; ";
                strEmail += " } ";

                strEmail += " a { ";
                strEmail += " color: #3498db; ";
                strEmail += " text-decoration: underline; ";
                strEmail += " } ";
                strEmail += " .btn { ";
                strEmail += " box-sizing: border-box; ";
                strEmail += " width: 100%; ";
                strEmail += " } ";

                strEmail += " .btn > tbody > tr > td { ";
                strEmail += " padding-bottom: 15px; ";
                strEmail += " } ";

                strEmail += " .btn table { ";
                strEmail += " width: auto; ";
                strEmail += " } ";

                strEmail += " .btn table td { ";
                strEmail += " background-color: #ffffff; ";
                strEmail += " border-radius: 5px; ";
                strEmail += " text-align: center; ";
                strEmail += " } ";

                strEmail += " .btn a { ";
                strEmail += " background-color: #ffffff; ";
                strEmail += " border: solid 1px #3498db; ";
                strEmail += " border-radius: 5px; ";
                strEmail += " box-sizing: border-box; ";
                strEmail += " color: #3498db; ";
                strEmail += " cursor: pointer; ";
                strEmail += " display: inline-block; ";
                strEmail += " font-size: 14px; ";
                strEmail += " font-weight: bold; ";
                strEmail += " margin: 0; ";
                strEmail += " padding: 12px 25px; ";
                strEmail += " text-decoration: none; ";
                strEmail += " text-transform: capitalize; ";
                strEmail += " } ";

                strEmail += " .btn-primary table td { ";
                strEmail += " background-color: #3498db; ";
                strEmail += " } ";

                strEmail += ".btn - primary a {  ";
                strEmail += " background-color: #3498db; ";
                strEmail += " border-color: #3498db; ";
                strEmail += " color: #ffffff; ";
                strEmail += " } ";
                strEmail += " .last { ";
                strEmail += " margin-bottom: 0; ";
                strEmail += " } ";

                strEmail += " .first { ";
                strEmail += " margin-top: 0; ";
                strEmail += " } ";

                strEmail += " .align-center { ";
                strEmail += " text-align: center; ";
                strEmail += " } ";

                strEmail += " .align-right { ";
                strEmail += " text-align: right; ";
                strEmail += " } ";

                strEmail += " .align-left { ";
                strEmail += " text-align: left; ";
                strEmail += " } ";

                strEmail += " .clear { ";
                strEmail += " clear: both; ";
                strEmail += " } ";

                strEmail += " .mt0 { ";
                strEmail += " margin-top: 0; ";
                strEmail += " } ";

                strEmail += " .mb0 { ";
                strEmail += " margin-bottom: 0; ";
                strEmail += " } ";

                strEmail += " .preheader { ";
                strEmail += " color: transparent; ";
                strEmail += " display: none; ";
                strEmail += " height: 0; ";
                strEmail += " max-height: 0; ";
                strEmail += " max-width: 0; ";
                strEmail += " opacity: 0; ";
                strEmail += " overflow: hidden; ";
                strEmail += " mso-hide: all; ";
                strEmail += " visibility: hidden; ";
                strEmail += " width: 0; ";
                strEmail += " } ";

                strEmail += " .powered-by a { ";
                strEmail += " text-decoration: none; ";
                strEmail += " } ";

                strEmail += " hr { ";
                strEmail += " border: 0; ";
                strEmail += " border-bottom: 1px solid #f6f6f6; ";
                strEmail += " Margin: 20px 0; ";
                strEmail += " } ";
                strEmail += " @media only screen and (max-width: 620px) { ";
                strEmail += " table[class=body] h1 { ";
                strEmail += " font-size: 28px !important; ";
                strEmail += " margin-bottom: 10px !important; ";
                strEmail += " } ";

                strEmail += " table[class=body] p, ";
                strEmail += " table[class=body] ul, ";
                strEmail += " table[class=body] ol, ";
                strEmail += " table[class=body] td, ";
                strEmail += " table[class=body] span, ";
                strEmail += " table[class=body] a { ";
                strEmail += " font-size: 16px !important; ";
                strEmail += " } ";

                strEmail += " table[class=body] .wrapper, ";
                strEmail += " table[class=body] .article { ";
                strEmail += " padding: 10px !important; ";
                strEmail += " } ";

                strEmail += " table[class=body] .content { ";
                strEmail += " padding: 0 !important; ";
                strEmail += " } ";

                strEmail += " table[class=body] .container { ";
                strEmail += " padding: 0 !important; ";
                strEmail += " width: 100% !important; ";
                strEmail += " } ";

                strEmail += " table[class=body] .main { ";
                strEmail += " border-left-width: 0 !important; ";
                strEmail += " border-radius: 0 !important; ";
                strEmail += " border-right-width: 0 !important; ";
                strEmail += " } ";

                strEmail += " table[class=body] .btn table { ";
                strEmail += " width: 100% !important; ";
                strEmail += " } ";

                strEmail += " table[class=body] .btn a { ";
                strEmail += " width: 100% !important; ";
                strEmail += " } ";

                strEmail += " table[class=body] .img-responsive { ";
                strEmail += " height: auto !important; ";
                strEmail += " max-width: 100% !important; ";
                strEmail += " width: auto !important; ";
                strEmail += " } ";
                strEmail += " } ";
                strEmail += " @media all { ";
                strEmail += " .ExternalClass { ";
                strEmail += " width: 100%; ";
                strEmail += " } ";

                strEmail += " .ExternalClass, ";
                strEmail += " .ExternalClass p, ";
                strEmail += " .ExternalClass span, ";
                strEmail += " .ExternalClass font, ";
                strEmail += " .ExternalClass td, ";
                strEmail += " .ExternalClass div { ";
                strEmail += " line-height: 100%; ";
                strEmail += " } ";

                strEmail += " .apple-link a { ";
                strEmail += " color: inherit !important; ";
                strEmail += " font-family: inherit !important; ";
                strEmail += " font-size: inherit !important; ";
                strEmail += " font-weight: inherit !important; ";
                strEmail += " line-height: inherit !important; ";
                strEmail += " text-decoration: none !important; ";
                strEmail += " } ";

                strEmail += " .btn-primary table td:hover { ";
                strEmail += " background-color: #34495e !important; ";
                strEmail += " } ";

                strEmail += " .btn-primary a:hover { ";
                strEmail += " background-color: #34495e !important; ";
                strEmail += " border-color: #34495e !important; ";
                strEmail += " } ";
                strEmail += " } ";
                strEmail += " </style> ";
                strEmail += " </head> ";
                strEmail += " <body class=''> ";

                strEmail += " <table border='0' cellpadding='0' cellspacing='0' class='body'> ";
                strEmail += " <tr> ";
                strEmail += " <td>&nbsp;</td> ";
                strEmail += " <td class='container'> ";
                strEmail += " <div class='content'> ";
                strEmail += " <span class='preheader'></span> ";
                strEmail += " <table class='main'> ";
                strEmail += " <tr> ";
                strEmail += " <td align='center'><h1 style='font-size:3vw; text-align: center; text-transform: uppercase; color: #347561; text-indent: 50px; text-align: justify; letter-spacing: 3px;'>Congratulations</h1></td> ";
                strEmail += " </tr> ";
                strEmail += " <tr> ";
                strEmail += " <td align='center'> ";
                //< img src = "images/icons/logo.png" />
                strEmail += " <img src='images/icons/logo.png' /> ";
                strEmail += " </td> ";
                strEmail += " </tr> ";
                strEmail += " <tr> ";
                strEmail += " <td class='wrapper'> ";
                strEmail += " <table border='0' cellpadding='0' cellspacing='0'> ";
                strEmail += " <tr> ";
                strEmail += " <td> ";
                strEmail += " <p>Hi " + name.ToUpper() + ",</p> ";
                strEmail += " <p>Congratulations on achieving your goal. I know what was involved in getting it accomplished in record breaking time and in not only meeting your goal but surpassing it!</p> ";
                strEmail += " <p>I'm so proud of you for setting your sights high, and making every effort to achieve that goal.You worked hard and proved to yourself and everyone what you are capable of.</p> ";
                strEmail += " <table border='0' cellpadding='0' cellspacing='0' class='btn btn-primary'> ";
                strEmail += " <tbody> ";
                strEmail += " <tr> ";
                strEmail += " <td align='left'> ";
                strEmail += " <table border='0' cellpadding='0' cellspacing='0'> ";
                strEmail += " <tbody> ";
                strEmail += " <tr> ";
                strEmail += " <td> <!--<a href='http://htmlemail.io' target='_blank'>Call To Action</a>--> </td> ";
                strEmail += " </tr> ";
                strEmail += " </tbody> ";
                strEmail += " </table> ";
                strEmail += " </td> ";
                strEmail += " </tr> ";
                strEmail += " </tbody> ";
                strEmail += " </table> ";
                strEmail += " <p>Best wishes for continued success.</p> ";
                strEmail += " <p>Regarding<br /> <br />Guduchi & Teams<br />Good luck.</p><a href='http://ourguduchi.com' target='_blank'>www.ourguduchi.com</a> ";
                strEmail += " </td> ";
                strEmail += " </tr> ";
                strEmail += " </table> ";
                strEmail += " </td> ";
                strEmail += " </tr> ";
                strEmail += " </table> ";
                strEmail += " </div> ";
                strEmail += " </td> ";
                strEmail += " <td>&nbsp;</td> ";
                strEmail += " </tr> ";
                strEmail += " </table> ";
                strEmail += " </body> ";
                strEmail += " </html> ";

            }
            catch (Exception ex)
            {
                strEmail = "";
                dbconn.SetError(ex.Message, "db : emailFormat");
            }
            return strEmail;
        }

        public bool checkNumber(long phone)
        {
            int ctr = 0;
            string sphone;
            while (phone > 0)
            {
                ctr++;
                phone /= 10;
            }
            if (ctr == 10)
            {
                sphone = phone.ToString();
                if (sphone.StartsWith("9") == true || sphone.StartsWith("8") || sphone.StartsWith("7") || sphone.StartsWith("6"))
                    return true;
                else
                    return false;
            }
            else
                return false;
        }

        public bool ValidateEmail(string email)
        {

            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regex.Match(email);
            if (match.Success)
                return true;
            else
                return false;
        }
    }
}